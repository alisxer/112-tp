from cmu_graphics import *
import time
import random

# Constants
mapWidth, mapHeight = 1000, 700
zoomFactor = 2
avatarWidth, avatarHeight = 70, 90
avatarSpeed = 10
screenWidthPercent, screenHeightPercent = 0.7, 0.7

# GameState Class
class GameState:
    def __init__(self):
        self.money = 100
        self.currentScreen = "welcome"
        self.screens = ["mainMap", "office", "stock", "news", "instructions", 
                        "menu", "stockAAPL", "stockBRIC", "stockBLDN", 
                        "stockGLD", "bank", "fixedDeposit", 'atm']
        self.completedLevels = []  # Track which difficulty levels the player has completed

# Player Class
class Player:
    def __init__(self):
        self.avatarX = 620
        self.avatarY = 325
        self.baseSpeed = avatarSpeed
        self.avatarSpeed = self.baseSpeed
        self.facingDirection = "right"
        self.moneyMultiplier = 1
        self.speedMultiplier = 1
        self.energyDrainRate = 1.0  # 1.0 is normal rate, lower is better
        self.healthRegenRate = 1.0  # For the smartwatch effect

    def updateMovement(self, app):
        dx, dy = 0, 0
        if 'left' in app.keysHeld:
            dx -= self.avatarSpeed
            self.facingDirection = "left"
        if 'right' in app.keysHeld:
            dx += self.avatarSpeed
            self.facingDirection = "right"
        if 'up' in app.keysHeld:
            dy -= self.avatarSpeed
        if 'down' in app.keysHeld:
            dy += self.avatarSpeed

        # Apply speed boost if active
        if "speedBoost" in app.inventory.activeEffects:
            dx *= app.inventory.activeEffects["speedBoost"]["multiplier"]
            dy *= app.inventory.activeEffects["speedBoost"]["multiplier"]

        newX = self.avatarX + dx
        newY = self.avatarY + dy
        newX = max(0, min(newX, mapWidth))
        newY = max(0, min(newY, mapHeight))

        if isOnRoad(newX, newY):
            self.avatarX, self.avatarY = newX, newY
            # Clear blocked message when movement succeeds
            if hasattr(app, 'blockedMessage'):
                app.blockedMessage = None
                app.blockedMessageTime = 0

# Office Class (Updated)
class Office:
    def __init__(self):
        self.words = ["hello", "world", "python", "code", "game", "office", 
                      "work", "money", "bank", "stock", "invest", "trade", "buy",
                      "sell", "profit", "loss", "market", "news", "report",
                      "analysis", "strategy", "portfolio", "dividend", "interest",
                      "investment", "capital", "assets", "liabilities", "equity",]
        
        self.targetWord = random.choice(self.words)
        self.userInput = ""
        self.errorCount = 0
        self.workTime = 0
        self.officeEntryTime = None
        self.officeTime = 8
        self.lastWorkDay = 1
        self.lastUpdateTime = None  # Add this to track the last update time
        self.maxWorkHours = 8  # Reduced from 10 to 8 hours
        self.basePayPerWord = 5  # Reduced from 15 to 5 for better balance

    def checkInput(self, app):
        if self.userInput == self.targetWord:
            # Calculate earnings based on word length and reduced base pay
            earnings = self.basePayPerWord * app.player.moneyMultiplier
            app.gameState.money += earnings
            self.targetWord = random.choice(self.words)
            self.userInput = ""
            self.errorCount = 0

# Bank Class
class Bank:
    def __init__(self):
        self.balance = 0  # Money in the bank account
        self.lastInterestUpdate = -1  # Track last 24-hour interest update (in game hours)
        self.inputAmount = ""  # Store user input for deposit/withdrawal
        self.inputActive = False  # Track if input field is active
        self.isWithdrawing = False  # Track if withdrawing (for shared input field)

    def updateInterest(self, app):
        currentHour = app.hour + app.day * 24  # Total hours since game start
        if currentHour != self.lastInterestUpdate and currentHour % 24 == 0:
            self.balance *= 1.05  # 5% interest every 24 game hours
            self.lastInterestUpdate = currentHour

    def deposit(self, app, amount):
        if amount <= app.gameState.money and amount > 0:
            self.balance += amount
            app.gameState.money -= amount
            return True
        return False

    def withdraw(self, app, amount):
        if amount <= self.balance and amount > 0:
            self.balance -= amount
            app.gameState.money += amount
            return True
        return False

class FixedDeposit:
    def __init__(self, amount, startDay, termDays):
        self.amount = amount  # Initial deposit amount
        self.startDay = startDay  # Day the deposit was made
        self.termDays = termDays  # Duration of the deposit (e.g., 5 days)
        self.maturityDay = startDay + termDays  # Day it matures
        self.interestRate = 0.10  # 10% per day

    def calculateValue(self, currentDay):
        daysElapsed = min(currentDay - self.startDay, self.termDays)
        return self.amount * (1 + self.interestRate) ** daysElapsed

    def isMatured(self, currentDay):
        return currentDay >= self.maturityDay

# Inventory Class
class Inventory:
    def __init__(self):
        self.items = {
            "speedBoost": {"count": 2, "duration": 60, "multiplier": 2},
            "moneyMultiplier": {"count": 1, "duration": 60, "multiplier": 2}
        }
        self.activeEffects = {}

    def useItem(self, app, item):
        if self.items[item]["count"] > 0:
            self.items[item]["count"] -= 1
            self.activeEffects[item] = {
                "multiplier": self.items[item]["multiplier"],
                "remainingTime": self.items[item]["duration"]
            }

    def applyEffects(self, app):
        for effect in list(self.activeEffects.keys()):
            self.activeEffects[effect]["remainingTime"] -= 1/30
            if self.activeEffects[effect]["remainingTime"] <= 0:
                del self.activeEffects[effect]
        if app.gameState.currentScreen == "office" and "moneyMultiplier" in self.activeEffects:
            app.player.moneyMultiplier = self.activeEffects["moneyMultiplier"]["multiplier"]
        else:
            app.player.moneyMultiplier = 1

# Mall Class
class Mall:
    def __init__(self):
        self.categories = ["Clothing", "Electronics", "Food", "Items"]
        self.currentCategory = "Items"  # Default category
        self.cart = []  # Items in shopping cart
        
        # Store items by category with their details
        self.inventory = {
            "Clothing": [
                {"id": "c1", "name": "Business Suit", "price": 200, "description": "Professional attire for office work", "effect": "Increases office earnings by 10%"},
                {"id": "c2", "name": "Casual Outfit", "price": 50, "description": "Comfortable everyday clothes", "effect": "Reduces energy drain by 5%"},
                {"id": "c3", "name": "Running Shoes", "price": 80, "description": "High-performance athletic footwear", "effect": "Increases movement speed by 15%"}
            ],
            "Electronics": [
                {"id": "e1", "name": "Smartphone", "price": 300, "description": "Latest model with stock tracking app", "effect": "Get notifications about big stock price changes"},
                {"id": "e2", "name": "Laptop", "price": 500, "description": "Powerful work computer", "effect": "Work from home feature unlocked"},
                {"id": "e3", "name": "Smartwatch", "price": 150, "description": "Fitness and health tracker", "effect": "Health regenerates 10% faster"}
            ],
            "Food": [
                {"id": "f1", "name": "Energy Drink", "price": 5, "description": "Quick energy boost", "effect": "+20 Energy instantly"},
                {"id": "f2", "name": "Healthy Meal", "price": 12, "description": "Balanced nutrition", "effect": "+10 Energy, improves health"},
                {"id": "f3", "name": "Luxury Dinner", "price": 30, "description": "Premium dining experience", "effect": "Full energy restore"}
            ],
            "Items": [
                {"id": "i1", "name": "Speed Boost", "price": 50, "description": "Temporary movement enhancement", "effect": "2x speed for 5 minutes"},
                {"id": "i2", "name": "Money Multiplier", "price": 100, "description": "Increase your earnings", "effect": "1.5x earnings for 5 minutes"},
                {"id": "i3", "name": "Stock Tip", "price": 200, "description": "Insider information on stocks", "effect": "Reveals a profitable stock opportunity"}
            ]
        }
        
        # Player's purchased items
        self.playerItems = {}
        # Selected item for detailed view
        self.selectedItem = None
        self.itemsForSale = {
            "speedBoost": {"price": 50, "description": "Speed Boost (2x speed, 5 min)"},
            "moneyMultiplier": {"price": 100, "description": "Money Multiplier (1.5x earnings, 5 min)"}
        }

# Stock Class
class Stock:
    def __init__(self):
        self.stocks = {
            "AAPL": {"name": "Apple Technology", "description": "A leading tech company known for innovative devices like the iPhone.", "minPrice": 100, "maxPrice": 130, "currentPrice": 100},
            "BRIC": {"name": "Bric Inc. Construction", "description": "An Italian construction company, renowned for big projects like Dubai Palm Marina.", "minPrice": 0.5, "maxPrice": 20, "currentPrice": 10},
            "BLDN": {"name": "Baladna Dairy", "description": "A major dairy producer in the Middle East, known for sustainable farming.", "minPrice": 20, "maxPrice": 55, "currentPrice": 30},
            "GLD": {"name": "Gold Commodity", "description": "A precious metal commodity, often used as a safe-haven investment.", "minPrice": 50, "maxPrice": 500, "currentPrice": 200}
        }
        self.portfolio = {}
        self.purchasePrices = {}
        self.lastPriceUpdateHour = -1
        self.quantityInput = ""
        self.selectedStock = None
        # Add price history for charting
        self.priceHistory = {stock: [self.stocks[stock]["currentPrice"]] for stock in self.stocks}
        self.maxHistoryLength = 24  # Keep last 24 hours of data

    def updatePrices(self, app):
        if app.gameState.currentScreen in ["menu", "instructions"]:
            return
        currentHour = app.hour
        if currentHour % 1 == 0 and currentHour != self.lastPriceUpdateHour:
            # Update all stocks with a base change, favoring upward movement
            for stock in self.stocks:
                changePercent = random.uniform(10, 20)
                # 75% chance of increase, 25% chance of decrease
                direction = random.choices([1, -1], weights=[75, 25])[0]
                changePercent *= direction
                currentPrice = self.stocks[stock]["currentPrice"]
                newPrice = currentPrice * (1 + changePercent / 100)
                self.stocks[stock]["currentPrice"] = max(self.stocks[stock]["minPrice"], min(self.stocks[stock]["maxPrice"], newPrice))
            # Apply news-driven changes
            for news in app.news.currentNews:
                stock = news["target"]
                if stock in self.stocks and news["type"] != "general":
                    changePercent = 0
                    if news["type"] == "positiveOne":
                        changePercent = random.uniform(1, 50)
                    elif news["type"] == "positiveTwo":
                        changePercent = random.uniform(10, 150)
                        if stock == "BRIC" and stock in self.portfolio:
                            changePercent = random.uniform(10, 15000)
                    elif news["type"] == "negativeOne":
                        changePercent = random.uniform(-50, -1)
                    elif news["type"] == "negativeTwo":
                        changePercent = random.uniform(-150, -10)
                    currentPrice = self.stocks[stock]["currentPrice"]
                    newPrice = currentPrice * (1 + changePercent / 100)
                    self.stocks[stock]["currentPrice"] = max(self.stocks[stock]["minPrice"], min(self.stocks[stock]["maxPrice"], newPrice))
            self.lastPriceUpdateHour = currentHour

# News Class
class News:
    def __init__(self):
        self.currentNews = []
        self.previousNews = set()  # Keep track of previous news text to avoid repetition
        self.lastNewsUpdateHour = -1
        self.newsTemplates = {
            "AAPL": {
                "positiveOne": [
                    "Apple announces a new iPhone with record-breaking pre-orders (+10-15%).", 
                    "Tech industry reports strong demand for Apple products (+8-12%).",
                    "Apple's wearables division reports unexpected sales growth (+10-18%).",
                    "Analysts upgrade Apple stock recommendation to 'strong buy' (+12-18%)."
                ],
                "positiveTwo": [
                    "Apple secures a major government contract for tech infrastructure (+20-30%).", 
                    "Apple stock soars after unveiling revolutionary AI technology (+25-40%).",
                    "Apple announces surprise acquisition of promising AI startup (+30-45%).",
                    "Apple beats quarterly earnings expectations by 40% (+35-50%)."
                ],
                "negativeOne": [
                    "Apple faces supply chain disruptions for new products (-10-15%).", 
                    "Tech sector sees a dip amid regulatory scrutiny on Apple (-8-12%).",
                    "Consumer reports shows declining satisfaction with Apple products (-12-18%).",
                    "Apple delays key product launch due to technical issues (-10-20%)."
                ],
                "negativeTwo": [
                    "Apple hit with a major lawsuit over patent infringement (-20-30%).", 
                    "Apple's new product launch fails to meet expectations (-25-40%).",
                    "Key Apple executives resign amid internal company turmoil (-30-45%).",
                    "Apple reports first quarterly loss in a decade (-35-50%)."
                ]
            },
            "BRIC": {
                "positiveOne": [
                    "Bric Inc. wins a contract for a new skyscraper in Dubai (+10-15%).", 
                    "Construction sector booms as Bric Inc. expands operations (+8-12%).",
                    "Bric Inc. introduces cost-saving construction techniques (+10-18%).",
                    "Bric's debt rating upgraded by major rating agencies (+12-18%)."
                ],
                "positiveTwo": [
                    "Bric Inc. completes a record-breaking project ahead of schedule (+20-30%).", 
                    "Bric Inc. stock skyrockets after a major international merger (+25-40%).",
                    "Bric Inc. signs multi-billion dollar contract in Saudi Arabia (+30-45%).",
                    "Bric Inc. revenue doubles after expansion to Asian markets (+35-50%)."
                ],
                "negativeOne": [
                    "Bric Inc. faces delays in a major construction project (-10-15%).", 
                    "Construction industry reports a slowdown affecting Bric Inc. (-8-12%).",
                    "Rising material costs expected to impact Bric's profit margins (-12-18%).",
                    "Labor dispute at Bric Inc. project site causes work stoppage (-10-20%)."
                ],
                "negativeTwo": [
                    "Bric Inc. under investigation for construction safety violations (-20-30%).", 
                    "Bric Inc. loses a major contract to a competitor (-25-40%).",
                    "Structural failure discovered in Bric's flagship building project (-30-45%).",
                    "Bric Inc. CEO resigns amid accounting irregularities probe (-35-50%)."
                ]
            },
            "BLDN": {
                "positiveOne": [
                    "Baladna Dairy secures a deal to supply milk to schools nationwide (+10-15%).", 
                    "Dairy industry thrives as Baladna expands production (+8-12%).",
                    "Baladna introduces new organic dairy product line (+10-18%).",
                    "Baladna Dairy wins sustainability award for eco-friendly practices (+12-18%)."
                ],
                "positiveTwo": [
                    "Baladna Dairy innovates with a new sustainable product line (+20-30%).", 
                    "Baladna stock surges after a major export deal with Europe (+25-40%).",
                    "Baladna acquires major competitor, doubling market share (+30-45%).",
                    "Baladna revolutionizes dairy industry with breakthrough technology (+35-50%)."
                ],
                "negativeOne": [
                    "Baladna Dairy faces a recall due to product contamination (-10-15%).", 
                    "Dairy prices drop, impacting Baladna's revenue (-8-12%).",
                    "New health study questions benefits of dairy products (-12-18%).",
                    "Baladna faces increased competition from plant-based alternatives (-10-20%)."
                ],
                "negativeTwo": [
                    "Baladna Dairy hit by a major outbreak affecting livestock (-20-30%).", 
                    "Baladna loses a key market due to new regulations (-25-40%).",
                    "Baladna Dairy announces major financial restructuring amid losses (-30-45%).",
                    "Quality control scandal erupts at Baladna's main production facility (-35-50%)."
                ]
            },
            "GLD": {
                "positiveOne": [
                    "Big investors prefer gold over federal bonds (+10-15%).", 
                    "Gold prices rise as global uncertainty increases demand (+8-12%).",
                    "Central bank gold buying reaches five-year high (+10-18%).",
                    "Jewelry demand for gold surges in Asian markets (+12-18%)."
                ],
                "positiveTwo": [
                    "Gold hits an all-time high amid economic instability (+20-30%).", 
                    "Central banks increase gold reserves, boosting prices (+25-40%).",
                    "Major currency devaluation drives investors to gold as safe haven (+30-45%).",
                    "Gold discoveries down 50%, supply constraints expected to drive prices (+35-50%)."
                ],
                "negativeOne": [
                    "Gold prices dip as investors shift to cryptocurrencies (-10-15%).", 
                    "Economic recovery reduces demand for gold (-8-12%).",
                    "Gold mining output increases, creating supply surplus (-12-18%).",
                    "Rising interest rates make gold less attractive as an investment (-10-20%)."
                ],
                "negativeTwo": [
                    "Gold market crashes after a major sell-off by investors (-20-30%).", 
                    "New mining technology floods the market with gold (-25-40%).",
                    "Major central banks announce gold reserve sales (-30-45%).",
                    "Gold loses status as safe haven as new investment alternative emerges (-35-50%)."
                ]
            },
            "general": [
                "Market reports steady growth across all sectors.", 
                "Global trade tensions ease, affecting all markets.", 
                "Economic forecast predicts stable inflation rates.",
                "Interest rates remain unchanged following central bank meeting.",
                "Consumer confidence index reaches three-year high.",
                "Manufacturing sector shows signs of slowing down.",
                "Unemployment rate falls to lowest level in decade.",
                "New trade agreement expected to boost international commerce.",
                "Market volatility increases amid geopolitical uncertainties.",
                "Retail sales data exceeds analyst expectations."
            ]
        }
        
        # Extract the impact percentages from news text for each type
        self.impactRanges = {stock: {} for stock in self.newsTemplates if stock != "general"}
        for stock in self.impactRanges:
            for newsType in ["positiveOne", "positiveTwo", "negativeOne", "negativeTwo"]:
                self.impactRanges[stock][newsType] = []
                for newsText in self.newsTemplates[stock][newsType]:
                    # Extract percentage range from the end of the text (e.g., "(+10-15%)")
                    if "(" in newsText and ")" in newsText:
                        impact = newsText[newsText.rfind("(")+1:newsText.rfind(")")]
                        # Strip the impact from the news text to display clean text to the player
                        self.newsTemplates[stock][newsType][self.newsTemplates[stock][newsType].index(newsText)] = newsText[:newsText.rfind("(")].strip()
                        
                        # Parse the percentage range
                        try:
                            if "-" in impact:
                                min_val, max_val = impact.replace("%", "").split("-")
                                min_val = float(min_val)
                                max_val = float(max_val)
                                if "+" in min_val:  # Handle positive impact
                                    min_val = float(min_val.replace("+", ""))
                                    self.impactRanges[stock][newsType].append((min_val/100, max_val/100))
                                else:  # Handle negative impact
                                    self.impactRanges[stock][newsType].append((min_val/100, max_val/100))
                        except Exception:
                            # Default impact if parsing fails
                            default = {"positiveOne": (0.1, 0.15), "positiveTwo": (0.2, 0.4), 
                                       "negativeOne": (-0.15, -0.1), "negativeTwo": (-0.4, -0.2)}
                            self.impactRanges[stock][newsType].append(default[newsType])

    def updateNews(self, app):
        if app.gameState.currentScreen in ["menu", "instructions"]:
            return
            
        currentHour = app.hour
        
        # Regular hourly stock price updates (even without news)
        if app.hour % 1 == 0 and currentHour != self.lastNewsUpdateHour:
            self._updateStockPricesRegularly(app)
        
        # Only update news and apply news-driven stock changes hourly
        if currentHour % 1 == 0 and currentHour != self.lastNewsUpdateHour:
            self.generateNews(app)
            self._applyNewsImpact(app)
            self.lastNewsUpdateHour = currentHour
    
    def _updateStockPricesRegularly(self, app):
        """Update stock prices with small random changes every hour"""
        for stock in app.stock.stocks:
            # 60% chance of increase, 40% chance of decrease
            direction = 1 if random.random() < 0.6 else -1
            # Random change between 5% and 15%
            changePercent = random.uniform(5, 15) / 100 * direction
            
            currentPrice = app.stock.stocks[stock]["currentPrice"]
            newPrice = currentPrice * (1 + changePercent)
            
            # Keep price within min-max bounds
            app.stock.stocks[stock]["currentPrice"] = max(
                app.stock.stocks[stock]["minPrice"], 
                min(app.stock.stocks[stock]["maxPrice"], newPrice)
            )
    
    def generateNews(self, app):
        """Generate new set of non-repeating news items"""
        self.currentNews = []
        stocks = list(app.stock.stocks.keys())  # ["AAPL", "BRIC", "BLDN", "GLD"]
        
        # Ensure 1 general news that hasn't been seen recently
        availableGeneralNews = [news for news in self.newsTemplates["general"] 
                               if news not in self.previousNews]
        if not availableGeneralNews:  # If all have been used, reset
            self.previousNews = set()
            availableGeneralNews = self.newsTemplates["general"]
            
        generalNewsText = random.choice(availableGeneralNews)
        self.currentNews.append({"text": generalNewsText, "type": "general", "target": None})
        self.previousNews.add(generalNewsText)
        
        # Select 3 unique stocks for news
        selectedStocks = random.sample(stocks, 3)
        
        # For each selected stock, generate a news item
        for stock in selectedStocks:
            # Randomly select news type with probability favoring positive news (more engaging)
            newsType = random.choices(
                ["positiveOne", "positiveTwo", "negativeOne", "negativeTwo"],
                weights=[40, 20, 30, 10],  # Higher weights for positive news
                k=1
            )[0]
            
            # Get all available news for this stock and type that haven't been used recently
            availableNews = [text for text in self.newsTemplates[stock][newsType] 
                            if text not in self.previousNews]
            
            if not availableNews:  # If all have been used, allow reuse of this type
                availableNews = self.newsTemplates[stock][newsType]
            
            if availableNews:  # Make sure we have news to select from
                newsText = random.choice(availableNews)
                self.currentNews.append({"text": newsText, "type": newsType, "target": stock})
                self.previousNews.add(newsText)
    
    def _applyNewsImpact(self, app):
        """Apply the impact of news items on stock prices"""
        for news in self.currentNews:
            if news["type"] == "general":
                continue  # General news doesn't directly impact stocks
                
            stock = news["target"]
            newsType = news["type"]
            
            # Get the appropriate impact range
            if newsType in self.impactRanges[stock] and self.impactRanges[stock][newsType]:
                impactRange = random.choice(self.impactRanges[stock][newsType])
                min_impact, max_impact = impactRange
                impact = random.uniform(min_impact, max_impact)
                
                # Apply the impact
                currentPrice = app.stock.stocks[stock]["currentPrice"]
                newPrice = currentPrice * (1 + impact)
                
                # Special case for BRIC stock positive news if player owns it
                if stock == "BRIC" and newsType.startswith("positive") and stock in app.stock.portfolio and app.stock.portfolio[stock] > 0:
                    # Boost impact for BRIC if the player owns it
                    impact *= random.uniform(1.5, 3.0)
                    newPrice = currentPrice * (1 + impact)
                
                # Keep price within min-max bounds
                app.stock.stocks[stock]["currentPrice"] = max(
                    app.stock.stocks[stock]["minPrice"], 
                    min(app.stock.stocks[stock]["maxPrice"], newPrice)
                )

# Define Entrances
def defineEntrances():
    return [
        {"name": "work", "screen": "office", "x": 120, "y": 530, "width": 60, "height": 40},  # 120 < x < 180, 530 < y < 570
        {"name": "mall", "screen": "mall", "x": 820, "y": 570, "width": 40, "height": 40},   # 820 < x < 860, 570 < y < 610
        {"name": "house", "screen": "house", "x": 440, "y": 520, "width": 70, "height": 60}, # 440 < x < 510, 520 < y < 580
        {"name": "news", "screen": "news", "x": 90, "y": 240, "width": 130, "height": 30},    # 90 < x < 220, 240 < y < 270
        {"name": "stock", "screen": "stock", "x": 420, "y": 230, "width": 140, "height": 50},# 420 < x < 560, 230 < y < 280
        {"name": "bank", "screen": "bank", "x": 810, "y": 235, "width": 70, "height": 20}    # 710 < x < 760, 270 < y < 290
    ]

# Define Road and Open Area Boundaries
def isOnRoad(x, y):
    # Main horizontal road
    if 40 <= x <= 950 and 235 <= y <= 345:
        return True
    # Vertical road 2
    if 660 <= x <= 710 and 75 <= y <= 665:
        return True
    # Vertical road 1
    if 260 <= x <= 310 and 75 <= y <= 665:
        return True
    
    # Open area for mall (expanded to connect to road)
    if 710 <= x <= 890 and 345 <= y <= 630:
        return True
    # Open area for house (expanded to connect to road)
    if 310 <= x <= 650 and 345 <= y <= 545:
        return True
    # Open area for work (expanded to connect to road)
    if 40 <= x <= 250 and 345 <= y <= 570:
        return True
    
    # Connections between roads and buildings
    # Wide corridor from main road to mall
    if 710 <= x <= 890 and 235 <= y <= 630:
        return True
    # Wide corridor from main road to house  
    if 310 <= x <= 650 and 235 <= y <= 545:
        return True
    # Wide corridor from main road to work area
    if 40 <= x <= 250 and 235 <= y <= 570:
        return True
    
    return False

def updateMapOffset(app):
    viewportWidth = mapWidth / zoomFactor
    viewportHeight = mapHeight / zoomFactor
    app.mapOffsetX = app.player.avatarX - viewportWidth / 2
    app.mapOffsetY = app.player.avatarY - viewportHeight / 2
    app.mapOffsetX = max(0, min(app.mapOffsetX, mapWidth - viewportWidth))
    app.mapOffsetY = max(0, min(app.mapOffsetY, mapHeight - viewportHeight))

def drawMoneyBar(app):
    drawRect(0, 0, mapWidth, 50, fill='black', opacity=80)
    # Draw day and time on the left
    drawLabel(f"Day {app.day}/{app.totalDays}, {app.hour:02d}:{app.minute:02d}", 
              90, 25, size=20, fill="white")
    
    # Energy bar - moved left and removed label
    if hasattr(app, 'energy'):
        # Draw energy bar background
        barWidth = 100
        barHeight = 15
        barX = 180  # Moved left from 260
        barY = 25 - barHeight/2
        drawRect(barX, barY, barWidth, barHeight, fill="darkGray", border="white")
        
        # Draw energy level
        energyWidth = (app.energy / 100) * barWidth
        energyColor = "green"
        if app.energy < 30:
            energyColor = "red"
        elif app.energy < 70:
            energyColor = "yellow"
        drawRect(barX, barY, energyWidth, barHeight, fill=energyColor)
        
        # Draw energy percentage
        drawLabel(f"{int(app.energy)}%", barX + barWidth/2, barY + barHeight/2, 
                  size=12, fill="black", bold=True)
    
    # Add appropriate message in the center
    centerMessage = ""
    if app.gameState.currentScreen == "mainMap":
        playerX = app.player.avatarX
        playerY = app.player.avatarY
        
        # Check if player is near any entrance
        nearEntrance = False
        for entrance in app.entrances:
            xMin = entrance["x"]
            xMax = entrance["x"] + entrance["width"]
            yMin = entrance["y"]
            yMax = entrance["y"] + entrance["height"]
            if xMin <= playerX <= xMax and yMin <= playerY <= yMax:
                nearEntrance = True
                # Special message for office if closed
                if entrance["screen"] == "office":
                    currentTime = app.hour + app.minute / 60
                    if currentTime < 8 or app.hour >= 18:
                        if app.hour >= 18:
                            centerMessage = "The office is closed until 8:00 AM tomorrow"
                        else:
                            centerMessage = f"The office is closed until 8:00 AM"
                    else:
                        centerMessage = "Press 'E' to enter"
                else:
                    centerMessage = "Press 'E' to enter"
                break
    elif app.gameState.currentScreen != "welcome" and app.gameState.currentScreen != "menu" and app.gameState.currentScreen != "instructions":
        centerMessage = "Press 'Q' to exit"
    
    if centerMessage:
        # Added more space for center message since energy bar moved left
        drawLabel(centerMessage, mapWidth / 2, 25, size=20, fill="white")
    
    # Draw money information on the right
    drawLabel(f"${app.gameState.money:.2f} / ${app.goalMoney:.2f}", 
              3 * mapWidth / 4, 25, size=20, fill="white")
    
    # Menu button
    drawRect(mapWidth - 100, 5, 90, 40, fill="gray", border="black")
    drawLabel("Menu", mapWidth - 55, 25, size=20, fill="black")

def drawMainMap(app):
    if app.isFullMapView:
        drawFullMap(app)
    else:
        drawZoomedMap(app)
    drawAvatar(app)
    
    # Debug visualization of road boundaries
    if app.showDebugRoads:
        # Main horizontal road
        drawRect(40, 235, 910, 110, fill=None, border='red', borderWidth=2)
        # Vertical road 2
        drawRect(660, 75, 50, 590, fill=None, border='red', borderWidth=2)
        # Vertical road 1
        drawRect(260, 75, 50, 590, fill=None, border='red', borderWidth=2)
        
        # Open area for mall
        drawRect(710, 345, 180, 285, fill=None, border='blue', borderWidth=2)
        # Open area for house
        drawRect(310, 345, 340, 200, fill=None, border='blue', borderWidth=2)
        # Open area for work
        drawRect(40, 345, 210, 225, fill=None, border='blue', borderWidth=2)
        
        # Connections between roads and buildings
        # Wide corridor to mall
        drawRect(710, 235, 180, 110, fill=None, border='green', borderWidth=2)
        # Wide corridor to house
        drawRect(310, 235, 340, 110, fill=None, border='green', borderWidth=2)
        # Wide corridor to work
        drawRect(40, 235, 210, 110, fill=None, border='green', borderWidth=2)
        
        # Building entrances
        for entrance in app.entrances:
            drawRect(entrance["x"], entrance["y"], entrance["width"], entrance["height"], 
                     fill=None, border='yellow', borderWidth=3)
        
        # Show avatar position
        drawLabel(f"Avatar: ({int(app.player.avatarX)}, {int(app.player.avatarY)})", 
                 mapWidth / 2, 60, size=16, fill='white')
        drawLabel("Press 'D' to toggle debug visualization", mapWidth / 2, 90, size=14, fill='yellow')
    
    # Display blocked movement message if exists
    if hasattr(app, 'blockedMessage') and app.blockedMessage and app.blockedMessageTime > 0:
        textX = app.player.avatarX
        textY = app.player.avatarY - 30
        if app.isFullMapView:
            # Display directly at avatar position in full map
            pass
        else:
            # Adjust for zoomed view
            textX = (app.player.avatarX - app.mapOffsetX) * zoomFactor
            textY = (app.player.avatarY - app.mapOffsetY) * zoomFactor - 30
        
        drawRect(textX - 100, textY - 15, 200, 30, fill='black', opacity=80)
        drawLabel(app.blockedMessage, textX, textY, size=14, fill='red', bold=True)
        app.blockedMessageTime -= 1
        if app.blockedMessageTime <= 0:
            app.blockedMessage = None
    
    drawMoneyBar(app)
    
    # Add night overlay if time is between 20:00 and 6:00
    if app.hour >= 20 or app.hour < 6:
        drawRect(0, 0, mapWidth, mapHeight, fill='black', opacity=70)
        drawLabel("NIGHT TIME", mapWidth / 2, 60, size=24, fill='yellow', bold=True)

def drawZoomedMap(app):
    screenX = -app.mapOffsetX * zoomFactor
    screenY = -app.mapOffsetY * zoomFactor
    drawImage("citymap.png", screenX, screenY, 
             width=mapWidth * zoomFactor, 
             height=mapHeight * zoomFactor)

def drawFullMap(app):
    drawImage("citymap.png", 0, 0, width=mapWidth, height=mapHeight)

def drawAvatar(app):
    if app.isFullMapView:
        screenX = app.player.avatarX - avatarWidth / 2
        screenY = app.player.avatarY - avatarHeight / 2
    else:
        screenX = (app.player.avatarX - app.mapOffsetX) * zoomFactor - avatarWidth / 2
        screenY = (app.player.avatarY - app.mapOffsetY) * zoomFactor - avatarHeight / 2
    if app.player.facingDirection == "right":
        drawImage("rightavatar.png", screenX, screenY, width=avatarWidth, height=avatarHeight)
    else:
        drawImage("leftavatar.png", screenX, screenY, width=avatarWidth, height=avatarHeight)

# Building Interior Drawing Functions (Updated drawOfficeScreen)
def drawOfficeScreen(app):
    drawImage("office.png", 0, 0, width=mapWidth, height=mapHeight)
    screenX = (mapWidth - app.screenWidth) / 2
    screenY = (mapHeight - app.screenHeight) / 2
    drawRect(screenX, screenY, app.screenWidth, app.screenHeight, fill="black")
    screenCenterX = screenX + app.screenWidth / 2
    screenCenterY = screenY + app.screenHeight / 2
    currentTime = app.hour + app.minute / 60
    if currentTime < 8 or app.hour >= 18 or app.office.workTime >= app.office.maxWorkHours:
        drawLabel("Office is closed (8:00 AM - 6:00 PM, max 10 hrs)", screenCenterX, screenCenterY, size=20, fill="white")
        drawLabel(f"Current Time: {app.hour:02d}:{app.minute:02d}", screenCenterX, screenCenterY + 30, size=20, fill="white")
        drawLabel(f"Work Time: {app.office.workTime:.2f} hrs", screenCenterX, screenCenterY + 60, size=20, fill="white")
        drawLabel("Press Q to return to map", screenCenterX, screenCenterY + 90, size=20, fill="black")
    else:
        officeHours = int(app.office.officeTime)
        officeMinutes = int((app.office.officeTime - officeHours) * 60)
        clockText = f"Office Time: {officeHours:02d}:{officeMinutes:02d}"
        drawLabel(clockText, screenCenterX, screenY + 60, size=20, fill="white")
        drawLabel(f"Work Time: {app.office.workTime:.2f} hrs", screenCenterX, screenY + 90, size=20, fill="white")
        drawLabel(f"Errors: {app.office.errorCount}", screenCenterX, screenY + 120, size=20, fill="white")
        drawLabel(app.office.targetWord, screenCenterX, screenCenterY - 50, size=30, fill="white")
        inputColor = "green" if app.office.userInput == app.office.targetWord[:len(app.office.userInput)] else "red"
        drawLabel(app.office.userInput, screenCenterX, screenCenterY, size=30, fill=inputColor)
        drawLabel("Type the word and press Enter", screenCenterX, screenCenterY + 50, size=20, fill="white")
        drawLabel("Press Q to return to map", screenCenterX, screenCenterY + 80, size=20, fill="black")
    drawMoneyBar(app)

def drawMenuScreen(app):
    # Background
    drawRect(0, 0, mapWidth, mapHeight, fill="black", opacity=70)
    
    # Title
    drawLabel("GAME MENU", mapWidth / 2, 100, size=36, fill="white", bold=True)
    
    # Buttons
    buttonWidth = 250
    buttonHeight = 40
    buttonSpacing = 20
    startY = 200
    
    # Continue Game Button
    drawRect(mapWidth / 2 - buttonWidth / 2, startY, buttonWidth, buttonHeight, fill="gray", border="white")
    drawLabel("Continue Game", mapWidth / 2, startY + buttonHeight / 2, size=18, fill="white", bold=True)
    
    # Instructions Button
    drawRect(mapWidth / 2 - buttonWidth / 2, startY + buttonHeight + buttonSpacing, buttonWidth, buttonHeight, fill="gray", border="white")
    drawLabel("Instructions", mapWidth / 2, startY + buttonHeight + buttonSpacing + buttonHeight / 2, size=18, fill="white", bold=True)
    
    # Quit Game Button
    drawRect(mapWidth / 2 - buttonWidth / 2, startY + 2 * (buttonHeight + buttonSpacing), buttonWidth, buttonHeight, fill="gray", border="white")
    drawLabel("Quit Game", mapWidth / 2, startY + 2 * (buttonHeight + buttonSpacing) + buttonHeight / 2, size=18, fill="white", bold=True)
    
    # Back Button
    drawRect(20, mapHeight - 60, 100, 40, fill="gray", border="white")
    drawLabel("Back", 70, mapHeight - 40, size=16, fill="white", bold=True)


def drawInstructionsScreen(app):
    # Background
    drawRect(0, 0, mapWidth, mapHeight, fill="darkBlue")
    
    # Title
    drawLabel("HOW TO PLAY", mapWidth / 2, 30, size=50, fill="gold", bold=True)
    drawLine(100, 65, mapWidth - 100, 65, fill="gold", lineWidth=3)
    
    # Instructions Sections
    sections = [
        {
            "title": "1. Navigation",
            "details": [
                "Use the arrow keys to move your character around the map.",
                "Press 'E' to enter buildings when near entrances.",
                "Press 'Q' to exit buildings and return to the map."
            ]
        },
        {
            "title": "2. Earning Money",
            "details": [
                "Work in the office to earn money by typing words correctly.",
                "Invest in stocks to grow your wealth over time.",
                "Deposit money in the bank to earn 5% daily interest."
            ]
        },
        {
            "title": "3. Managing Energy",
            "details": [
                "Your energy decreases as you move or work.",
                "Eat food or rest at home to restore energy.",
                "Low energy reduces your movement speed."
            ]
        },
        {
            "title": "4. Winning the Game",
            "details": [
                "Reach your goal money before the time runs out.",
                "Choose a difficulty level at the start of the game.",
                "Plan your actions wisely to maximize earnings."
            ]
        }
    ]
    
    # Layout for sections
    startY = 100
    sectionSpacing = 130
    for i, section in enumerate(sections):
        y = startY + i * sectionSpacing
        
        # Section title with icon
        drawLabel(f"{section['title']}", mapWidth / 2, y, size=25, fill="white", bold=True)
        
        # Section details
        detailStartY = y + 40
        for j, detail in enumerate(section["details"]):
            drawLabel(f"- {detail}", mapWidth / 2, detailStartY + j * 25, size=14, fill="lightGray")
    
    # Back Button
    drawRect(20, mapHeight - 60, 120, 40, fill="gray", border="white")
    drawLabel("Back", 80, mapHeight - 40, size=18, fill="white", bold=True)
    
def drawStockScreenAAPL(app):
    drawImage("stockInterior.png", 0, 0, width=mapWidth, height=mapHeight)
    drawRect(0, 0, mapWidth, mapHeight, fill="black", opacity=80)
    stockInfo = app.stock.stocks["AAPL"]
    ownedShares = app.stock.portfolio.get("AAPL", 0)
    screenCenterX = mapWidth / 2
    screenCenterY = mapHeight / 2
    drawLabel("AAPL - Apple Technology", screenCenterX, screenCenterY - 150, size=30, fill="white")
    drawLabel(stockInfo["description"], screenCenterX, screenCenterY - 110, size=20, fill="white")
    drawLabel(f"Current Price: ${stockInfo['currentPrice']:.1f}", screenCenterX, screenCenterY - 70, size=20, fill="white")
    drawLabel(f"Owned Shares: {ownedShares}", screenCenterX, screenCenterY - 50, size=20, fill="white")
    drawLabel(f"Quantity: {app.stock.quantityInput}", screenCenterX, screenCenterY - 30, size=20, fill="white")
    drawRect(screenCenterX - 60, screenCenterY + 20, 120, 40, fill="green", border="black")
    drawLabel("Buy", screenCenterX, screenCenterY + 40, size=20, fill="black")
    drawRect(screenCenterX + 70, screenCenterY + 20, 60, 40, fill="yellow", border="black")
    drawLabel("MAX", screenCenterX + 100, screenCenterY + 40, size=16, fill="black")
    drawRect(screenCenterX - 60, screenCenterY + 70, 120, 40, fill="red", border="black")
    drawLabel("Sell", screenCenterX, screenCenterY + 90, size=20, fill="black")
    drawRect(screenCenterX + 70, screenCenterY + 70, 60, 40, fill="yellow", border="black")
    drawLabel("MAX", screenCenterX + 100, screenCenterY + 90, size=16, fill="black")
    drawRect(screenCenterX - 60, screenCenterY + 120, 120, 40, fill="gray", border="black")
    drawLabel("Back", screenCenterX, screenCenterY + 140, size=20, fill="black")
    drawMoneyBar(app)

def drawStockScreenBRIC(app):
    drawImage("stockInterior.png", 0, 0, width=mapWidth, height=mapHeight)
    drawRect(0, 0, mapWidth, mapHeight, fill="black", opacity=80)
    stockInfo = app.stock.stocks["BRIC"]
    screenCenterX = mapWidth / 2
    screenCenterY = mapHeight / 2
    drawLabel("BRIC - Bric Inc. Construction", screenCenterX, screenCenterY - 150, size=30, fill="white")
    drawLabel(stockInfo["description"], screenCenterX, screenCenterY - 110, size=20, fill="white")
    drawLabel(f"Current Price: ${stockInfo['currentPrice']:.1f}", screenCenterX, screenCenterY - 70, size=20, fill="white")
    drawLabel(f"Quantity: {app.stock.quantityInput}", screenCenterX, screenCenterY - 30, size=20, fill="white")
    drawRect(screenCenterX - 60, screenCenterY + 20, 120, 40, fill="green", border="black")
    drawLabel("Buy", screenCenterX, screenCenterY + 40, size=20, fill="black")
    drawRect(screenCenterX + 70, screenCenterY + 20, 60, 40, fill="yellow", border="black")
    drawLabel("MAX", screenCenterX + 100, screenCenterY + 40, size=16, fill="black")
    drawRect(screenCenterX - 60, screenCenterY + 70, 120, 40, fill="red", border="black")
    drawLabel("Sell", screenCenterX, screenCenterY + 90, size=20, fill="black")
    drawRect(screenCenterX + 70, screenCenterY + 70, 60, 40, fill="yellow", border="black")
    drawLabel("MAX", screenCenterX + 100, screenCenterY + 90, size=16, fill="black")
    drawRect(screenCenterX - 60, screenCenterY + 120, 120, 40, fill="gray", border="black")
    drawLabel("Back", screenCenterX, screenCenterY + 140, size=20, fill="black")
    drawMoneyBar(app)

def drawStockScreenBLDN(app):
    drawImage("stockInterior.png", 0, 0, width=mapWidth, height=mapHeight)
    drawRect(0, 0, mapWidth, mapHeight, fill="black", opacity=80)
    stockInfo = app.stock.stocks["BLDN"]
    screenCenterX = mapWidth / 2
    screenCenterY = mapHeight / 2
    drawLabel("BLDN - Baladna Dairy", screenCenterX, screenCenterY - 150, size=30, fill="white")
    drawLabel(stockInfo["description"], screenCenterX, screenCenterY - 110, size=20, fill="white")
    drawLabel(f"Current Price: ${stockInfo['currentPrice']:.1f}", screenCenterX, screenCenterY - 70, size=20, fill="white")
    drawLabel(f"Quantity: {app.stock.quantityInput}", screenCenterX, screenCenterY - 30, size=20, fill="white")
    drawRect(screenCenterX - 60, screenCenterY + 20, 120, 40, fill="green", border="black")
    drawLabel("Buy", screenCenterX, screenCenterY + 40, size=20, fill="black")
    drawRect(screenCenterX + 70, screenCenterY + 20, 60, 40, fill="yellow", border="black")
    drawLabel("MAX", screenCenterX + 100, screenCenterY + 40, size=16, fill="black")
    drawRect(screenCenterX - 60, screenCenterY + 70, 120, 40, fill="red", border="black")
    drawLabel("Sell", screenCenterX, screenCenterY + 90, size=20, fill="black")
    drawRect(screenCenterX + 70, screenCenterY + 70, 60, 40, fill="yellow", border="black")
    drawLabel("MAX", screenCenterX + 100, screenCenterY + 90, size=16, fill="black")
    drawRect(screenCenterX - 60, screenCenterY + 120, 120, 40, fill="gray", border="black")
    drawLabel("Back", screenCenterX, screenCenterY + 140, size=20, fill="black")
    drawMoneyBar(app)

def drawStockScreenGLD(app):
    drawImage("stockInterior.png", 0, 0, width=mapWidth, height=mapHeight)
    drawRect(0, 0, mapWidth, mapHeight, fill="black", opacity=80)
    stockInfo = app.stock.stocks["GLD"]
    screenCenterX = mapWidth / 2
    screenCenterY = mapHeight / 2
    drawLabel("GLD - Gold Commodity", screenCenterX, screenCenterY - 150, size=30, fill="white")
    drawLabel(stockInfo["description"], screenCenterX, screenCenterY - 110, size=20, fill="white")
    drawLabel(f"Current Price: ${stockInfo['currentPrice']:.1f}", screenCenterX, screenCenterY - 70, size=20, fill="white")
    drawLabel(f"Quantity: {app.stock.quantityInput}", screenCenterX, screenCenterY - 30, size=20, fill="white")
    drawRect(screenCenterX - 60, screenCenterY + 20, 120, 40, fill="green", border="black")
    drawLabel("Buy", screenCenterX, screenCenterY + 40, size=20, fill="black")
    drawRect(screenCenterX + 70, screenCenterY + 20, 60, 40, fill="yellow", border="black")
    drawLabel("MAX", screenCenterX + 100, screenCenterY + 40, size=16, fill="black")
    drawRect(screenCenterX - 60, screenCenterY + 70, 120, 40, fill="red", border="black")
    drawLabel("Sell", screenCenterX, screenCenterY + 90, size=20, fill="black")
    drawRect(screenCenterX + 70, screenCenterY + 70, 60, 40, fill="yellow", border="black")
    drawLabel("MAX", screenCenterX + 100, screenCenterY + 90, size=16, fill="black")
    drawRect(screenCenterX - 60, screenCenterY + 120, 120, 40, fill="gray", border="black")
    drawLabel("Back", screenCenterX, screenCenterY + 140, size=20, fill="black")
    drawMoneyBar(app)

def drawPortfolioScreen(app):
    # Background with gradient effect
    drawRect(0, 0, mapWidth, mapHeight, fill="darkBlue")
    for i in range(10):
        opacity = 80 - i * 6
        drawRect(0, i * mapHeight/10, mapWidth, mapHeight/10, fill="purple", opacity=opacity)
    
    # Portfolio title banner
    drawRect(0, 50, mapWidth, 70, fill="black", opacity=80, border="gold")
    screenCenterX = mapWidth / 2
    drawLabel("INVESTMENT PORTFOLIO", screenCenterX, 85, size=42, fill="gold", bold=True)
    
    # Value summary box
    totalValue = 0
    totalProfitLoss = 0
    for stock, quantity in app.stock.portfolio.items():
        if quantity > 0:
            currentPrice = app.stock.stocks[stock]["currentPrice"]
            stockValue = quantity * currentPrice
            totalValue += stockValue
            purchasePrices = app.stock.purchasePrices.get(stock, [])
            avgPurchasePrice = sum(purchasePrices) / len(purchasePrices) if purchasePrices else 0
            profitLoss = (currentPrice - avgPurchasePrice) * quantity
            totalProfitLoss += profitLoss
    
    # Portfolio value summary with decorative elements
    summaryBoxY = 150
    drawRect(screenCenterX - 250, summaryBoxY, 500, 100, fill="black", opacity=70, border="gold")
    
    # Add decorative dollar sign
    drawLabel("$", screenCenterX - 220, summaryBoxY + 50, size=60, fill="gold", bold=True)
    
    # Summary text - moved to top left as requested
    drawLabel(f"Total Portfolio Value:", screenCenterX - 160, summaryBoxY + 30, size=24, fill="white", bold=True, align="left")
    valueColor = "green" if totalValue > 0 else "white"
    drawLabel(f"${totalValue:.2f}", screenCenterX - 160, summaryBoxY + 60, size=32, fill=valueColor, bold=True, align="left")
    
    # P&L moved to bottom right as requested
    profitColor = "green" if totalProfitLoss >= 0 else "red"
    profitSymbol = "▲" if totalProfitLoss >= 0 else "▼"
    drawLabel(f"Profit/Loss: {profitSymbol} ${abs(totalProfitLoss):.2f}", 
              screenCenterX + 200, summaryBoxY + 80, 
              size=18, fill=profitColor, bold=True, align="right")
    
    # Stock holdings section
    holdingsY = summaryBoxY + 120
    drawRect(50, holdingsY, mapWidth - 100, 320, fill="black", opacity=70)
    
    # Section header
    drawRect(50, holdingsY, mapWidth - 100, 40, fill="darkBlue", border="gold")
    drawLabel("STOCK HOLDINGS", screenCenterX, holdingsY + 20, size=24, fill="white", bold=True)
    
    # Column headers
    headerY = holdingsY + 60
    drawLabel("STOCK", 150, headerY, size=18, fill="gold", bold=True)
    drawLabel("SHARES", 300, headerY, size=18, fill="gold", bold=True)
    drawLabel("PRICE", 450, headerY, size=18, fill="gold", bold=True)
    drawLabel("VALUE", 600, headerY, size=18, fill="gold", bold=True)
    drawLabel("PROFIT/LOSS", 780, headerY, size=18, fill="gold", bold=True)
    
    # Draw line under headers
    drawLine(80, headerY + 15, mapWidth - 130, headerY + 15, fill="gold", lineWidth=2)
    
    # List stocks with alternating row colors
    rowY = headerY + 40
    rowHeight = 45
    hasHoldings = False
    
    for stock, quantity in app.stock.portfolio.items():
        if quantity > 0:
            hasHoldings = True
            rowColor = "navy" if (rowY - headerY) // rowHeight % 2 == 0 else "darkBlue"
            drawRect(80, rowY - rowHeight/2, mapWidth - 160, rowHeight, fill=rowColor, opacity=70, border="gray")
            
            # Stock symbol with company icon placeholder
            drawCircle(110, rowY, 15, fill="gray")
            drawLabel(stock[0], 110, rowY, size=14, fill="white", bold=True)
            drawLabel(stock, 150, rowY, size=16, fill="white", bold=True, align="left")
            
            # Quantity
            drawLabel(f"{quantity}", 300, rowY, size=16, fill="white")
            
            # Current price
            currentPrice = app.stock.stocks[stock]["currentPrice"]
            drawLabel(f"${currentPrice:.2f}", 450, rowY, size=16, fill="white")
            
            # Total value
            stockValue = quantity * currentPrice
            drawLabel(f"${stockValue:.2f}", 600, rowY, size=16, fill="white")
            
            # Profit/Loss calculation
            purchasePrices = app.stock.purchasePrices.get(stock, [])
            avgPurchasePrice = sum(purchasePrices) / len(purchasePrices) if purchasePrices else 0
            profitLoss = (currentPrice - avgPurchasePrice) * quantity
            profitColor = "green" if profitLoss >= 0 else "red"
            profitSymbol = "▲" if profitLoss >= 0 else "▼"
            
            drawLabel(f"{profitSymbol} ${abs(profitLoss):.2f}", 780, rowY, size=16, fill=profitColor, bold=True)
            
            rowY += rowHeight
    
    # No holdings message
    if not hasHoldings:
        drawLabel("You don't have any stocks in your portfolio yet.", screenCenterX, headerY + 100, 
                 size=18, fill="white", italic=True)
        drawLabel("Visit the Stock Exchange to start investing!", screenCenterX, headerY + 130, 
                 size=18, fill="white", italic=True)
    
    # Navigation buttons with better styling
    buttonY = holdingsY + 340
    
    # Back button
    drawRect(150, buttonY, 160, 50, fill="gray", border="white")
    drawLabel("BACK", 230, buttonY + 25, size=20, fill="white", bold=True)
    
    # Stock Exchange button - 20px wider as requested
    drawRect(screenCenterX - 90, buttonY, 180, 50, fill="darkBlue", border="white")
    drawLabel("STOCK EXCHANGE", screenCenterX, buttonY + 25, size=18, fill="white", bold=True)
    
    # Trade button
    drawRect(mapWidth - 310, buttonY, 160, 50, fill="green", border="white")
    drawLabel("TRADE", mapWidth - 230, buttonY + 25, size=20, fill="white", bold=True)
    
    drawMoneyBar(app)

def drawBankScreen(app):
    # Background image with opacity
    drawImage("bankInterior.png", 0, 0, width=app.width, height=app.height)
    # Add a semi-transparent rectangle overlay
    drawRect(0, 0, app.width, app.height, fill="black", opacity=70)
    
    screenCenterX, screenCenterY = app.width // 2, app.height // 2
    
    # Bank Account Balance - larger and more prominent
    drawLabel(f"Bank Account Balance: ${app.bank.balance:.2f}", screenCenterX, 100, size=30, fill="white", bold=True)
    drawLabel("(5% Interest Every 24 Game Hours)", screenCenterX, 140, size=16, fill="lightGray")
    
    # Deposit Section with styled buttons
    drawLabel("Enter amount to deposit:", screenCenterX, 200, size=18, fill="white")
    drawRect(screenCenterX - 150, 230, 300, 40, fill="white", border="black")
    if not app.bank.isWithdrawing:
        drawLabel(app.bank.inputAmount or "0", screenCenterX, 250, size=18, fill="black")
    
    # Interactive deposit button
    depositButtonColor = "green"
    if not app.bank.inputAmount or not app.bank.inputAmount.isdigit() or int(app.bank.inputAmount) <= 0:
        depositButtonColor = "gray"
    elif app.bank.inputAmount.isdigit() and int(app.bank.inputAmount) > app.gameState.money:
        depositButtonColor = "gray"
        
    drawRect(screenCenterX - 75, 290, 150, 40, fill=depositButtonColor, border="black")
    drawLabel("Deposit", screenCenterX, 310, size=18, fill="white", bold=True)
    
    # ATM notice - styled as a button
    drawRect(screenCenterX - 150, 350, 300, 40, fill="red", border="black")
    drawLabel("Access ATM (Press 'W')", screenCenterX, 370, size=18, fill="white", bold=True)
    
    # Fixed Deposit Button - more prominent
    drawRect(screenCenterX - 150, 410, 300, 40, fill="blue", border="black")
    drawLabel("Fixed Deposits", screenCenterX, 430, size=18, fill="white", bold=True)
    
    # Back Button
    drawRect(20, 20, 80, 30, fill="gray", border="black")
    drawLabel("Back", 60, 35, size=14, fill="white")

    drawMoneyBar(app)

def drawFixedDepositScreen(app):
    screenCenterX, screenCenterY = app.width // 2, app.height // 2
    # Background
    drawRect(0, 0, app.width, app.height, fill="darkBlue")
    # Title
    drawLabel("Fixed Deposits (10% Daily Interest)", screenCenterX, 50, size=30, fill="white", bold=True)
    # Instructions
    drawLabel("Deposit money for a fixed term to earn 10% daily interest!", screenCenterX, 80, size=16, fill="lightGray")
    drawLabel("Current Term: 5 Days", screenCenterX, 100, size=14, fill="lightGray")
    # Input field for new deposit
    drawRect(screenCenterX - 100, 130, 200, 30, fill="white", border="black")
    drawLabel(f"Deposit Amount: {app.bank.inputAmount or '0'}", screenCenterX, 145, size=14, fill="black")
    # Deposit button
    drawRect(screenCenterX - 50, 170, 100, 30, fill="green", border="black")
    drawLabel("Deposit", screenCenterX, 185, size=14, fill="white", bold=True)
    # List of active fixed deposits
    y = 230
    drawLabel("Active Fixed Deposits", screenCenterX, y, size=20, fill="white", bold=True)
    y += 30
    if not app.fixedDeposits:
        drawLabel("No active fixed deposits.", screenCenterX, y, size=16, fill="lightGray")
    else:
        for i, fd in enumerate(app.fixedDeposits):
            currentValue = fd.calculateValue(app.day)
            matured = fd.isMatured(app.day)
            status = "Matured" if matured else f"Matures on Day {fd.maturityDay}"
            drawRect(screenCenterX - 300, y - 15, 600, 30, fill="black", opacity=50)
            drawLabel(f"Deposit {i+1}: ${fd.amount:.2f} | Current Value: ${currentValue:.2f} | {status}", screenCenterX, y, size=14, fill="white")
            if matured:
                drawRect(screenCenterX + 220, y - 10, 80, 20, fill="orange", border="black")
                drawLabel("Claim", screenCenterX + 260, y, size=12, fill="white")
            y += 40
    # Back button
    drawRect(20, 20, 80, 30, fill="gray", border="black")
    drawLabel("Back", 60, 35, size=14, fill="white")

def drawAtmScreen(app):
    # Background image with opacity
    drawImage("bankInterior.png", 0, 0, width=app.width, height=app.height)
    # Add a semi-transparent rectangle overlay
    drawRect(0, 0, app.width, app.height, fill="black", opacity=70)
    
    screenCenterX, screenCenterY = app.width // 2, app.height // 2
    
    # Account Balance - larger and more prominent
    drawLabel(f"Bank Account Balance: ${app.bank.balance:.2f}", screenCenterX, 100, size=30, fill="white", bold=True)
    
    # Withdrawal Section with styled input
    drawLabel("Enter amount to withdraw:", screenCenterX, 200, size=22, fill="white")
    drawRect(screenCenterX - 150, 230, 300, 40, fill="white", border="black")
    drawLabel(app.bank.inputAmount or "0", screenCenterX, 250, size=18, fill="black")
    
    # Interactive withdrawal button
    withdrawButtonColor = "red"
    if not app.bank.inputAmount or not app.bank.inputAmount.isdigit() or int(app.bank.inputAmount) <= 0:
        withdrawButtonColor = "gray"
    elif app.bank.inputAmount.isdigit() and int(app.bank.inputAmount) > app.bank.balance:
        withdrawButtonColor = "gray"
        
    drawRect(screenCenterX - 75, 290, 150, 40, fill=withdrawButtonColor, border="black")
    drawLabel("Withdraw", screenCenterX, 310, size=18, fill="white", bold=True)
    drawLabel("(Press Enter to confirm)", screenCenterX, 340, size=14, fill="lightGray")
    
    # Quick withdrawal buttons
    drawLabel("Quick Withdrawal:", screenCenterX, 380, size=18, fill="white")
    
    # Add buttons for common amounts
    buttonWidth = 90
    buttonSpacing = 20
    totalWidth = buttonWidth * 3 + buttonSpacing * 2
    startX = screenCenterX - totalWidth / 2
    
    for i, amount in enumerate([50, 100, 200]):
        buttonColor = "orange" if app.bank.balance >= amount else "gray"
        x = startX + i * (buttonWidth + buttonSpacing)
        drawRect(x, 400, buttonWidth, 40, fill=buttonColor, border="black")
        drawLabel(f"${amount}", x + buttonWidth/2, 420, size=16, fill="black", bold=True)
    
    # Back Button
    drawRect(20, 20, 80, 30, fill="gray", border="black")
    drawLabel("Back", 60, 35, size=14, fill="white")
    
    drawMoneyBar(app)

def drawNewsScreen(app):
    # Background image with opacity overlay
    drawImage("newsInterior.png", 0, 0, width=mapWidth, height=mapHeight)
    drawRect(0, 0, mapWidth, mapHeight, fill="gray", opacity=80)
    
    screenCenterX = mapWidth / 2
    screenCenterY = mapHeight / 2
    
    # Title and header section
    drawRect(0, 50, mapWidth, 60, fill="darkBlue", opacity=90)
    drawLabel("FINANCIAL NEWS NETWORK", screenCenterX, 80, size=36, fill="white", bold=True)
    
    # Current time display
    drawLabel(f"Market Update - Day {app.day}, {app.hour:02d}:{app.minute:02d}", 
              screenCenterX, 120, size=18, fill="white", italic=True)
    
    # News categories tabs
    tabWidth = mapWidth / 4  # 4 tabs total
    tabHeight = 40
    tabY = 150
    tabCategories = ["Headlines", "Analysis", "Stocks", "Portfolio"]
    
    # Track which tab is active
    if not hasattr(app, 'activeNewsTab'):
        app.activeNewsTab = "Headlines"
    
    for i, category in enumerate(tabCategories):
        x = i * tabWidth
        # Highlight the active tab
        tabColor = "darkBlue" if category == app.activeNewsTab else "gray"
        drawRect(x, tabY, tabWidth, tabHeight, fill=tabColor, border="black")
        drawLabel(category, x + tabWidth/2, tabY + tabHeight/2, size=18, fill="white", bold=True)
    
    # Main news content area
    contentY = tabY + tabHeight + 10
    contentHeight = mapHeight - contentY - 50
    
    # Display content based on active tab
    if app.activeNewsTab == "Headlines":
        # Left column - News items
        leftColumnWidth = mapWidth * 0.6
        drawRect(10, contentY, leftColumnWidth - 20, contentHeight, fill="white", opacity=70)
        
        # News header
        drawRect(10, contentY, leftColumnWidth - 20, 40, fill="darkBlue")
        drawLabel("BREAKING NEWS", leftColumnWidth/2, contentY + 20, size=20, fill="white", bold=True)
        
        # Display news items
        newsY = contentY + 60
        newsLineHeight = contentHeight / 6
        lineColors = ["lightGray", "white"]  # Alternating row colors
        
        for i, news in enumerate(app.news.currentNews):
            lineColor = lineColors[i % 2]
            impactColor = "white"  # Default
            
            if news["type"] != "general":
                # Color-code based on news impact
                if news["type"].startswith("positive"):
                    impactColor = "green"
                elif news["type"].startswith("negative"):
                    impactColor = "red"
                    
                # Draw stock symbol tag
                drawRect(15, newsY - 15, 80, 30, fill="darkBlue", border="black")
                drawLabel(news["target"], 55, newsY, size=16, fill="white", bold=True)
                
                # Draw impact indicator
                impact = "▲" if news["type"].startswith("positive") else "▼"
                impactSize = "▲▲" if "Two" in news["type"] else "▲"
                if impact == "▼":
                    impactSize = "▼▼" if "Two" in news["type"] else "▼"
                drawLabel(impactSize, 120, newsY, size=20, fill=impactColor, bold=True)
            else:
                # Draw "GENERAL" tag for general news
                drawRect(15, newsY - 15, 80, 30, fill="purple", border="black")
                drawLabel("MARKET", 55, newsY, size=16, fill="white", bold=True)
            
            # News item background
            drawRect(15, newsY - 15, leftColumnWidth - 30, newsLineHeight, fill=lineColor, opacity=50)
            
            # News text with word wrapping
            maxTextWidth = leftColumnWidth - 170
            textX = 150
            newsText = news["text"]
            
            # Truncate or wrap long text
            if len(newsText) > 60:
                firstLine = newsText[:57]
                secondLine = "..."
                lastSpaceIndex = firstLine.rfind(" ", 47, 57)
                if lastSpaceIndex != -1:
                    secondLine = firstLine[lastSpaceIndex+1:] + "..."
                    firstLine = firstLine[:lastSpaceIndex]
                
                drawLabel(firstLine, textX, newsY - 10, size=16, fill="black", 
                         bold=(news["type"] != "general"), align="left")
                drawLabel(secondLine, textX, newsY + 10, size=16, fill="black", 
                         bold=(news["type"] != "general"), align="left")
            else:
                drawLabel(newsText, textX, newsY, size=16, fill="black", 
                         bold=(news["type"] != "general"), align="left")
            
            newsY += newsLineHeight
        
        # Right column - Stock market summary
        rightX = leftColumnWidth
        rightWidth = mapWidth - leftColumnWidth
        
        # Market summary section
        drawRect(rightX, contentY, rightWidth, 180, fill="white", opacity=70)
        drawRect(rightX, contentY, rightWidth, 40, fill="darkBlue")
        drawLabel("MARKET SUMMARY", rightX + rightWidth/2, contentY + 20, size=20, fill="white", bold=True)
        
        # Display stock prices and changes
        summaryY = contentY + 60
        for i, stock in enumerate(app.stock.stocks):
            stockInfo = app.stock.stocks[stock]
            
            # Get price history to calculate change
            history = app.stock.priceHistory[stock]
            priceChange = 0
            changePercent = 0
            if len(history) > 1:
                priceChange = history[-1] - history[-2]
                changePercent = (priceChange / history[-2]) * 100 if history[-2] > 0 else 0
            
            # Color code based on price change
            changeColor = "green" if priceChange >= 0 else "red"
            changeSymbol = "▲" if priceChange >= 0 else "▼"
            
            # Background for each row
            rowColor = lineColors[i % 2]
            drawRect(rightX + 5, summaryY - 15, rightWidth - 10, 30, fill=rowColor, opacity=50)
            
            # Stock name and symbol
            drawLabel(f"{stock}", rightX + 40, summaryY, size=16, fill="black", bold=True)
            
            # Current price and change
            priceX = rightX + rightWidth - 120
            drawLabel(f"${stockInfo['currentPrice']:.2f}", priceX, summaryY, size=16, fill="black")
            drawLabel(f"{changeSymbol} {abs(changePercent):.1f}%", rightX + rightWidth - 40, 
                     summaryY, size=16, fill=changeColor, bold=True)
            
            summaryY += 30
        
        # Chart section - only if price history available
        if len(app.stock.priceHistory["AAPL"]) > 1:
            # Default stock
            chartStock = app.stock.selectedStock or "AAPL"
            
            # Chart container
            chartY = contentY + 200
            chartHeight = contentHeight - 200 - 20
            drawRect(rightX, chartY, rightWidth, chartHeight, fill="white", opacity=70)
            
            # Chart title
            drawRect(rightX, chartY, rightWidth, 30, fill="darkBlue")
            stockName = app.stock.stocks[chartStock]["name"]
            drawLabel(f"{chartStock} - {stockName}", rightX + rightWidth/2, chartY + 15, 
                     size=16, fill="white", bold=True)
            
            # Draw chart for the selected stock
            drawStockChartWithRange(app, chartStock, rightX, chartY, rightWidth, chartHeight, 24)
    
    elif app.activeNewsTab == "Analysis":
        # Analysis tab - show all 4 stock charts in a grid with their last 5-hour performance
        drawRect(10, contentY, mapWidth - 20, contentHeight, fill="white", opacity=70)
        
        # Title
        drawRect(10, contentY, mapWidth - 20, 40, fill="darkBlue")
        drawLabel("MARKET ANALYSIS - ALL STOCKS", screenCenterX, contentY + 20, size=20, fill="white", bold=True)
        
        # Create a grid of 4 charts (2x2)
        chartPadding = 20
        chartWidth = (mapWidth - 20 - (chartPadding * 3)) / 2
        chartHeight = (contentHeight - 40 - (chartPadding * 2)) / 2
        
        # Get all stock symbols
        stockSymbols = list(app.stock.stocks.keys())
        
        # Draw each chart in the grid
        for i, stock in enumerate(stockSymbols):
            row = i // 2
            col = i % 2
            
            chartX = 10 + (chartWidth + chartPadding) * col
            chartY = contentY + 50 + (chartHeight + chartPadding) * row
            
            # Chart background with clickable area
            drawRect(chartX, chartY, chartWidth, chartHeight, fill="lightGray", opacity=70)
            
            # Make it look interactive
            drawRect(chartX, chartY, chartWidth, chartHeight, fill=None, border="darkBlue", borderWidth=2)
            
            # Chart title with stock info
            drawRect(chartX, chartY, chartWidth, 30, fill="darkBlue")
            stockName = app.stock.stocks[stock]["name"]
            drawLabel(f"{stock} - {stockName}", chartX + chartWidth/2, chartY + 15, size=14, fill="white", bold=True)
            
            # Get price history for the last 5 hours or whatever is available
            history = app.stock.priceHistory[stock]
            recentHistory = history[-min(5, len(history)):] if len(history) > 0 else []
            
            # Display current price and recent change
            currentPrice = app.stock.stocks[stock]["currentPrice"]
            priceChange = 0
            changePercent = 0
            
            if len(recentHistory) > 1:
                priceChange = recentHistory[-1] - recentHistory[0]
                changePercent = (priceChange / recentHistory[0]) * 100 if recentHistory[0] > 0 else 0
            
            # Color code based on price change
            changeColor = "green" if priceChange >= 0 else "red"
            changeSymbol = "▲" if priceChange >= 0 else "▼"
            
            # Show price info above the chart
            drawLabel(f"Current: ${currentPrice:.2f}", 
                     chartX + chartWidth/5, chartY + 45, size=14, fill="black", bold=True, align="left")
            drawLabel(f"5hr Change: {changeSymbol} {abs(changePercent):.1f}%", 
                     chartX + chartWidth*4/5, chartY + 45, size=14, fill=changeColor, bold=True, align="right")
            
            # Draw the stock chart (recent 5 hours only)
            drawStockChartWithRange(app, stock, chartX, chartY + 15, chartWidth, chartHeight - 15, 5)
    
    # Other tabs would just redirect to their respective screens
    
    # Back button
    drawRect(20, mapHeight - 60, 120, 40, fill="gray", border="black")
    drawLabel("Back to Map", 80, mapHeight - 40, size=18, fill="white", bold=True)
    
    drawMoneyBar(app)

# Helper function to draw stock charts with a specific time range
def drawStockChartWithRange(app, stock, x, y, width, height, hoursToShow=5):
    # Calculate chart dimensions
    chartPadding = 30
    plotX = x + chartPadding
    plotY = y + 50
    plotWidth = width - 2 * chartPadding
    plotHeight = height - 80
    
    # Draw chart axes
    drawLine(plotX, plotY, plotX, plotY + plotHeight, fill="black")  # Y-axis
    drawLine(plotX, plotY + plotHeight, plotX + plotWidth, plotY + plotHeight, fill="black")  # X-axis
    
    # Get price data to plot - only the most recent hours
    history = app.stock.priceHistory[stock]
    recentHistory = history[-min(hoursToShow, len(history)):] if len(history) > 0 else []
    
    if len(recentHistory) >= 2:
        # Calculate scale for Y-axis
        minPrice = min(recentHistory)
        maxPrice = max(recentHistory)
        if minPrice == maxPrice:  # Handle flat chart
            minPrice = 0.9 * minPrice
            maxPrice = 1.1 * maxPrice
        
        # Plot price points and connect with lines
        prevX, prevY = None, None
        
        for i, price in enumerate(recentHistory):
            # Calculate position on chart
            x = plotX + (i / (len(recentHistory) - 1)) * plotWidth if len(recentHistory) > 1 else plotX
            y = plotY + plotHeight - ((price - minPrice) / (maxPrice - minPrice) * plotHeight) if maxPrice > minPrice else plotY + plotHeight/2
            
            # Draw point
            drawCircle(x, y, 3, fill="blue")
            
            # Connect points with line
            if prevX is not None:
                drawLine(prevX, prevY, x, y, fill="blue", lineWidth=2)
            
            prevX, prevY = x, y
        
        # Label Y-axis (price)
        drawLabel(f"${maxPrice:.2f}", plotX - 15, plotY, size=12, fill="black", align="right")
        drawLabel(f"${minPrice:.2f}", plotX - 15, plotY + plotHeight, size=12, fill="black", align="right")
        
        # Label X-axis (time)
        maxLabels = min(5, len(recentHistory))
        if len(recentHistory) > 0:
            step = max(1, len(recentHistory) // maxLabels)
            for i in range(0, len(recentHistory), step):
                if i < len(recentHistory):
                    hourIndex = (app.hour - len(recentHistory) + i) % 24
                    x = plotX + (i / (len(recentHistory) - 1)) * plotWidth
                    drawLabel(f"{hourIndex:02d}:00", x, plotY + plotHeight + 15, size=10, fill="black")
    else:
        # Not enough data for chart
        drawLabel("Not enough price history data", x + width/2, y + height/2, size=14, fill="black")

def drawMallScreen(app):
    # Background
    drawImage("mallInterior.png", 0, 0, width=mapWidth, height=mapHeight)
    
    # Semi-transparent overlay
    drawRect(0, 0, mapWidth, mapHeight, fill="white", opacity=60)
    
    screenCenterX = mapWidth / 2
    
    # Mall Title Banner
    drawRect(0, 50, mapWidth, 60, fill="purple", opacity=90)
    drawLabel("SHOPPING MALL", screenCenterX, 80, size=36, fill="white", bold=True)
    
    # Category tabs
    tabWidth = mapWidth / len(app.mall.categories)
    tabHeight = 40
    tabY = 130
    
    for i, category in enumerate(app.mall.categories):
        x = i * tabWidth
        # Highlight the selected category
        tabColor = rgb(48,25,52) if category == app.mall.currentCategory else "purple"
        tabOpacity = 100 if category == app.mall.currentCategory else 70
        
        drawRect(x, tabY, tabWidth, tabHeight, fill=tabColor, opacity=tabOpacity, border="white")
        drawLabel(category, x + tabWidth/2, tabY + tabHeight/2, size=20, fill="white", bold=True)
    
    # Main content area
    contentY = tabY + tabHeight + 10
    contentHeight = mapHeight - contentY - 60
    
    # Left panel - Item listing
    leftPanelWidth = mapWidth * 0.6
    drawRect(10, contentY, leftPanelWidth - 20, contentHeight, fill="white", opacity=70, border="purple")
    
    # Header for item list
    drawRect(10, contentY, leftPanelWidth - 20, 40, fill="purple")
    drawLabel(f"{app.mall.currentCategory} FOR SALE", leftPanelWidth/2, contentY + 20, size=20, fill="white", bold=True)
    
    # Display items in the current category
    items = app.mall.inventory.get(app.mall.currentCategory, [])
    itemY = contentY + 60
    itemHeight = min(90, (contentHeight - 60) / max(len(items), 1))
    
    for i, item in enumerate(items):
        # Alternating row colors
        rowColor = "lavender" if i % 2 == 0 else "white"
        isSelected = app.mall.selectedItem == item["id"]
        
        # Highlight selected item
        if isSelected:
            rowColor = "lightBlue"
            
        # Item row background
        drawRect(15, itemY - 10, leftPanelWidth - 30, itemHeight, 
                fill=rowColor, opacity=80, border="purple" if isSelected else None)
        
        # Item details
        iconX = 40
        textX = 170  # Start text after icon area
        
        # Placeholder for item image - you can replace with actual item images
        drawCircle(iconX, itemY + itemHeight/2 - 10, 30, fill="gray", border="black")
        drawLabel(item["name"][0].upper(), iconX, itemY + itemHeight/2 - 10, size=22, fill="white", bold=True)
        
        # Item name and price
        drawLabel(item["name"], textX, itemY + 10, size=18, fill="black", bold=True, align="left")
        drawLabel(f"${item['price']}", leftPanelWidth - 80, itemY + 10, size=18, fill="green", bold=True)
        
        # Brief description
        descriptionY = itemY + 30
        drawLabel(item["description"], textX, descriptionY, size=14, fill="black", align="left")
        
        # Effect preview
        drawLabel(item["effect"], textX, descriptionY + 20, size=12, fill="purple", italic=True, align="left")
        
        itemY += itemHeight
    
    # Right panel - Selected item detail or cart
    rightX = leftPanelWidth
    rightWidth = mapWidth - leftPanelWidth
    
    # Cart/Details panel
    drawRect(rightX + 10, contentY, rightWidth - 20, contentHeight, fill="white", opacity=70, border="purple")
    
    if app.mall.selectedItem:
        # Find the selected item
        selectedItem = None
        for category in app.mall.inventory:
            for item in app.mall.inventory[category]:
                if item["id"] == app.mall.selectedItem:
                    selectedItem = item
                    break
            if selectedItem:
                break
        
        if selectedItem:
            # Item detail view
            drawRect(rightX + 10, contentY, rightWidth - 20, 40, fill="purple")
            drawLabel("ITEM DETAILS", rightX + rightWidth/2, contentY + 20, size=20, fill="white", bold=True)
            
            detailY = contentY + 60
            
            # Large item icon
            iconX = rightX + rightWidth/2
            drawCircle(iconX, detailY + 50, 50, fill="gray", border="black")
            drawLabel(selectedItem["name"][0].upper(), iconX, detailY + 50, size=36, fill="white", bold=True)
            
            # Item name and price
            nameY = detailY + 120
            drawLabel(selectedItem["name"], rightX + rightWidth/2, nameY, size=24, fill="black", bold=True)
            drawLabel(f"Price: ${selectedItem['price']}", rightX + rightWidth/2, nameY + 40, size=20, fill="green", bold=True)
            
            # Detailed description
            descY = nameY + 80
            drawLabel("Description:", rightX + rightWidth/2, descY, size=18, fill="black", bold=True)
            drawLabel(selectedItem["description"], rightX + rightWidth/2, descY + 30, size=16, fill="black")
            
            # Effect
            effectY = descY + 70
            drawLabel("Effect:", rightX + rightWidth/2, effectY, size=18, fill="purple", bold=True)
            drawLabel(selectedItem["effect"], rightX + rightWidth/2, effectY + 30, size=16, fill="purple")
            
            # Buy button
            buttonY = effectY + 80
            buttonColor = "green" if app.gameState.money >= selectedItem["price"] else "gray"
            drawRect(rightX + rightWidth/2 - 60, buttonY, 120, 40, fill=buttonColor, border="black")
            drawLabel("BUY", rightX + rightWidth/2, buttonY + 20, size=20, fill="white", bold=True)
    else:
        # Shopping cart view
        drawRect(rightX + 10, contentY, rightWidth - 20, 40, fill="purple")
        drawLabel("YOUR CART", rightX + rightWidth/2, contentY + 20, size=20, fill="white", bold=True)
        
        if not app.mall.cart:
            # Empty cart message
            drawLabel("Your shopping cart is empty", rightX + rightWidth/2, contentY + contentHeight/2, 
                     size=16, fill="gray", italic=True)
        else:
            # Display cart items
            cartY = contentY + 60
            cartItemHeight = min(60, (contentHeight - 120) / max(len(app.mall.cart), 1))
            
            totalCost = 0
            for i, itemId in enumerate(app.mall.cart):
                # Find item details
                item = None
                for category in app.mall.inventory:
                    for catalogItem in app.mall.inventory[category]:
                        if catalogItem["id"] == itemId:
                            item = catalogItem
                            break
                    if item:
                        break
                
                if item:
                    totalCost += item["price"]
                    rowColor = "lavender" if i % 2 == 0 else "white"
                    
                    # Item row
                    drawRect(rightX + 15, cartY - 5, rightWidth - 30, cartItemHeight, fill=rowColor, opacity=80)
                    
                    # Item name and price
                    drawLabel(item["name"], rightX + 100, cartY + cartItemHeight/2 - 10, 
                             size=16, fill="black", bold=True, align="left")
                    drawLabel(f"${item['price']}", rightX + rightWidth - 60, cartY + cartItemHeight/2 - 10, 
                             size=16, fill="green")
                    
                    # Remove button
                    drawRect(rightX + 30, cartY + cartItemHeight/2 - 15, 30, 30, fill="red", border="black")
                    drawLabel("X", rightX + 45, cartY + cartItemHeight/2, size=16, fill="white", bold=True)
                    
                    cartY += cartItemHeight
            
            # Checkout section
            checkoutY = contentY + contentHeight - 100
            drawRect(rightX + 20, checkoutY, rightWidth - 40, 80, fill="lightGray", border="black")
            
            # Total cost
            drawLabel(f"Total: ${totalCost}", rightX + rightWidth/2, checkoutY + 20, size=20, fill="black", bold=True)
            
            # Checkout button
            buttonColor = "green" if app.gameState.money >= totalCost else "gray"
            drawRect(rightX + rightWidth/2 - 60, checkoutY + 50, 120, 30, fill=buttonColor, border="black")
            drawLabel("CHECKOUT", rightX + rightWidth/2, checkoutY + 65, size=16, fill="white", bold=True)
    
    # Back button
    drawRect(20, mapHeight - 50, 120, 40, fill="gray", border="black")
    drawLabel("Back to Map", 80, mapHeight - 30, size=18, fill="white", bold=True)
    
    drawMoneyBar(app)

def drawStockScreen(app):
    drawImage("stockInterior.png", 0, 0, width=mapWidth, height=mapHeight)
    drawRect(0, 0, mapWidth, mapHeight, fill="gray", opacity=80)
    screenCenterX = mapWidth / 2
    screenCenterY = mapHeight / 2
    drawLabel("Stock Market", screenCenterX, screenCenterY - 150, size=40, fill="white")
    stockKeys = list(app.stock.stocks.keys())
    totalWidth = 800
    rectWidth = totalWidth // 4
    startX = (mapWidth - totalWidth) // 2
    y = screenCenterY - 50
    for i in range(4):
        stock = stockKeys[i]
        stockInfo = app.stock.stocks[stock]
        x = startX + i * rectWidth
        drawRect(x, y, rectWidth, 80, fill="lightGray", border="black")
        drawLabel(f"{stock}", x + rectWidth / 2, y + 20, size=20, fill="black")
        drawLabel(f"${stockInfo['currentPrice']:.1f}", x + rectWidth / 2, y + 40, size=16, fill="black")
        drawLabel(f"Click to view", x + rectWidth / 2, y + 60, size=14, fill="black")
    drawRect(screenCenterX - 100, screenCenterY + 50, 200, 40, fill="lightGray", border="black")
    drawLabel("View Portfolio", screenCenterX, screenCenterY + 70, size=20, fill="black")
    drawRect(screenCenterX - 60, screenCenterY + 100, 120, 40, fill="gray", border="black")
    drawLabel("Back", screenCenterX, screenCenterY + 120, size=20, fill="black")
    drawMoneyBar(app)

def drawWelcomeScreen(app):
    # Background
    drawRect(0, 0, mapWidth, mapHeight, fill="darkBlue")
    
    # Main title with dollar signs
    drawLabel("$ $ $ FINANCIAL SIMULATOR $ $ $", mapWidth / 2, 120, size=45, fill="gold", bold=True)
    
    # Placeholder for main picture
    drawImage("welcomePic.jpeg", mapWidth / 2 - 150, 150, width=300, height=180)
    
    # Choose difficulty section
    drawLabel("Choose Difficulty:", mapWidth / 2, 380, size=30, fill="white", bold=True)
    
    # Difficulty options with dollar signs and updated targets
    # Easy is more challenging, and medium/hard are even more difficult
    drawLabel("1: Easy ($8,000 in 15 days)", 500, 430, size=25, fill="green", bold=True)
    
    # Display levels based on completion status
    if "easy" in app.gameState.completedLevels:
        drawLabel("2: Medium ($25,000 in 30 days)", 500, 480, size=25, fill=rgb(255,145,0), bold=True)
    else:
        drawLabel("2: Medium (Complete Easy Level First)", 500, 480, size=25, fill="gray", italic=True)
    
    if "medium" in app.gameState.completedLevels:
        drawLabel("3: Hard ($75,000 in 30 days)", 500, 530, size=25, fill="red", bold=True)
    else:
        drawLabel("3: Hard (Complete Medium Level First)", 500, 530, size=25, fill="gray", italic=True)
    
    # Dollar sign decorations in corners
    drawLabel("$", 50, 50, size=70, fill="gold", bold=True)
    drawLabel("$", mapWidth - 50, 50, size=70, fill="gold", bold=True)
    drawLabel("$", 50, mapHeight - 50, size=70, fill="gold", bold=True)
    drawLabel("$", mapWidth - 50, mapHeight - 50, size=70, fill="gold", bold=True)
    
    # Add note about investment necessity
    drawLabel("Hint: You must invest wisely to succeed!", mapWidth / 2, 580, size=18, fill="white", italic=True)

def drawHouseScreen(app):
    # Background image
    drawImage("houseInterior.png", 0, 0, width=mapWidth, height=mapHeight)
    
    screenCenterX = mapWidth / 2
    screenCenterY = mapHeight / 2
    
    # Title
    drawRect(0, 50, mapWidth, 60, fill="brown", opacity=80)
    drawLabel("HOME", screenCenterX, 80, size=40, fill="white", bold=True)
    
    # Current time display
    drawLabel(f"Time: {app.hour:02d}:{app.minute:02d}", screenCenterX, 130, size=24, fill="black", bold=True)
    
    # Activity buttons - arrange in a grid
    # Move buttons down 30 pixels
    buttonWidth = 200
    buttonHeight = 80
    buttonSpacing = 40
    startY = 240  # Updated to move buttons down (was 220)
    
    # Sleep button
    drawRect(screenCenterX - buttonWidth - buttonSpacing/2, startY, buttonWidth, buttonHeight, 
            fill="darkBlue", border="black")
    drawLabel("SLEEP", screenCenterX - buttonWidth/2 - buttonSpacing/2, startY + buttonHeight/2, 
             size=24, fill="white", bold=True)
    drawLabel("(Press S)", screenCenterX - buttonWidth/2 - buttonSpacing/2, startY + buttonHeight/2 + 30, 
             size=16, fill="white")
    
    # Eat button
    drawRect(screenCenterX + buttonSpacing/2, startY, buttonWidth, buttonHeight, 
            fill="green", border="black")
    drawLabel("EAT", screenCenterX + buttonWidth/2 + buttonSpacing/2, startY + buttonHeight/2, 
             size=24, fill="white", bold=True)
    drawLabel("(Press E)", screenCenterX + buttonWidth/2 + buttonSpacing/2, startY + buttonHeight/2 + 30, 
             size=16, fill="white")
    
    # TV button
    drawRect(screenCenterX - buttonWidth - buttonSpacing/2, startY + buttonHeight + buttonSpacing, 
            buttonWidth, buttonHeight, fill="purple", border="black")
    drawLabel("WATCH TV", screenCenterX - buttonWidth/2 - buttonSpacing/2, 
             startY + buttonHeight + buttonSpacing + buttonHeight/2, size=24, fill="white", bold=True)
    drawLabel("(Press T)", screenCenterX - buttonWidth/2 - buttonSpacing/2, 
             startY + buttonHeight + buttonSpacing + buttonHeight/2 + 30, size=16, fill="white")
    
    # Rest button
    drawRect(screenCenterX + buttonSpacing/2, startY + buttonHeight + buttonSpacing, 
            buttonWidth, buttonHeight, fill="orange", border="black")
    drawLabel("REST", screenCenterX + buttonWidth/2 + buttonSpacing/2, 
             startY + buttonHeight + buttonSpacing + buttonHeight/2, size=24, fill="white", bold=True)
    drawLabel("(Press R)", screenCenterX + buttonWidth/2 + buttonSpacing/2, 
             startY + buttonHeight + buttonSpacing + buttonHeight/2 + 30, size=16, fill="white")
    
    # Status panel - moved down to account for button shift
    statusY = startY + 2 * (buttonHeight + buttonSpacing) + 30
    drawRect(screenCenterX - 250, statusY, 500, 100, fill="white", border="black", opacity=80)
    
    # Show different status messages based on activity
    if hasattr(app, 'houseActivity'):
        if app.houseActivity == "sleeping":
            drawLabel(f"Sleeping... Will wake up at 7:30 tomorrow", 
                     screenCenterX, statusY + 30, size=20, fill="black")
            drawLabel(f"+100% Energy", 
                     screenCenterX, statusY + 60, size=18, fill="darkBlue")
        elif app.houseActivity == "eating":
            drawLabel("Eating a nutritious meal...", 
                     screenCenterX, statusY + 30, size=20, fill="black")
            drawLabel("+10 Energy, +5 Health", 
                     screenCenterX, statusY + 60, size=18, fill="darkGreen")
        elif app.houseActivity == "watching_tv":
            drawLabel("Relaxing in front of the TV...", 
                     screenCenterX, statusY + 30, size=20, fill="black")
            drawLabel("+5 Energy, -2 Money (Subscription)", 
                     screenCenterX, statusY + 60, size=18, fill="purple")
        elif app.houseActivity == "resting":
            drawLabel("Taking a short rest...", 
                     screenCenterX, statusY + 30, size=20, fill="black")
            drawLabel("+15 Energy", 
                     screenCenterX, statusY + 60, size=18, fill="orange")
    else:
        drawLabel("Select an activity", 
                 screenCenterX, statusY + 50, size=20, fill="black")
    
    # Back button
    drawRect(20, mapHeight - 60, 120, 40, fill="gray", border="black")
    drawLabel("Back to Map", 80, mapHeight - 40, size=18, fill="black", bold=True)
    
    drawMoneyBar(app)

# Application Logic
def onAppStart(app):
    app.screenWidth = mapWidth * screenWidthPercent
    app.screenHeight = mapHeight * screenHeightPercent
    app.mapWidth = mapWidth
    app.mapHeight = mapHeight
    app.gameState = GameState()
    app.player = Player()
    app.office = Office()
    app.bank = Bank()
    app.inventory = Inventory()
    app.mall = Mall()
    app.stock = Stock()
    app.news = News()
    app.startupDelay = 2
    app.keysHeld = set()
    app.showPortfolio = False
    
    # Game time variables
    app.counter = 0
    app.day = 1
    app.hour = 8
    app.minute = 0
    app.gameSpeed = 1
    app.goalMoney = 5000  # Default goal, will be set based on difficulty
    app.totalDays = 15    # Default days, will be set based on difficulty
    app.daysLeft = app.totalDays - app.day
    app.isPaused = False
    app.previousScreen = "mainMap"
    
    # Initialize current difficulty and completed levels
    app.currentDifficulty = None
    if not hasattr(app.gameState, 'completedLevels'):
        app.gameState.completedLevels = []
    
    # Map and avatar variables
    app.entrances = defineEntrances()
    app.mapOffsetX = app.player.avatarX - (app.screenWidth / zoomFactor) / 2
    app.mapOffsetY = app.player.avatarY - (app.screenHeight / zoomFactor) / 2
    app.isFullMapView = False

    #sound stuff
    app.mainMusic = Sound('music.mp3')
    app.winMusic = Sound('bugatti.mp3')
    app.isMusicPlaying = False  # Track if music is playing
    app.mainMusic.play(loop=True)  # Start playing music in a loop
    app.isMusicPlaying = True
    
    # House activities
    app.houseActivity = None
    app.wakeupHour = 7
    app.wakeupMinute = 30
    
    # Energy system
    app.energy = 100  # Max energy
    
    # News tab tracking
    app.activeNewsTab = "Headlines"
    
    # Fixed deposits
    app.fixedDeposits = []  # List to store active fixed deposits
    app.fixedDepositTerm = 5  # Default term for fixed deposits (5 days)
    
    # Debug message variables
    app.blockedMessage = None
    app.blockedMessageTime = 0
    
    # Debug options
    app.showDebugRoads = False  # Toggle for showing road boundaries
    print(f"Initial screen: {app.gameState.currentScreen}")

def onStep(app):
    if app.startupDelay > 0:
        app.startupDelay -= 1/30
    if app.gameState.currentScreen in ["menu", "instructions"]:
        return
    app.counter += 1
    if app.counter >= 8:  # 1 minute = 7 steps, so 1 hour = 60 * 7 = 420 steps ≈ 14 seconds
        app.minute += 1
        app.counter = 0
        if app.minute >= 60:
            app.minute = 0
            app.hour += 1
            # Track stock price history hourly
            for stock in app.stock.stocks:
                currentPrice = app.stock.stocks[stock]["currentPrice"]
                app.stock.priceHistory[stock].append(currentPrice)
                # Keep history limited to maxHistoryLength
                if len(app.stock.priceHistory[stock]) > app.stock.maxHistoryLength:
                    app.stock.priceHistory[stock].pop(0)
            
            # Decrease energy slower (2.5x slower than before)
            if hasattr(app, 'energy'):
                app.energy = max(0, app.energy - (2 * app.player.energyDrainRate))  # Use player's energyDrainRate
            
            if app.hour >= 24:
                app.hour = 0
                app.day += 1
                if app.gameState.currentScreen != "welcome":
                    app.daysLeft = app.totalDays - app.day
                    if app.daysLeft <= 0 and app.gameState.money < app.goalMoney:
                        app.gameState.currentScreen = "gameOver"
    if app.gameState.currentScreen == "mainMap":
        if not app.isFullMapView:
            app.player.updateMovement(app)
            updateMapOffset(app)

    app.bank.updateInterest(app)
    app.inventory.applyEffects(app)
    app.news.updateNews(app)  # News class now handles stock price updates

    # Apply energy effects on player movement
    if hasattr(app, 'energy'):
        energyFactor = app.energy / 100  # Energy percentage as a decimal
        # Reduce speed when energy is low
        app.player.avatarSpeed = app.player.baseSpeed * max(0.5, energyFactor) * app.player.speedMultiplier

    if app.gameState.currentScreen == "office":
        if app.day > app.office.lastWorkDay and app.hour >= 8:
            app.office.workTime = 0
            app.office.lastWorkDay = app.day
        if app.office.officeEntryTime is not None:

            currentTime = time.time()
            elapsedRealSeconds = (currentTime - app.office.officeEntryTime)
            officeHoursPassed = elapsedRealSeconds / 15  # 1 real-world minute = 1 office hour
            app.office.officeTime = 8 + officeHoursPassed

            # Calculate delta since last update
            if app.office.lastUpdateTime is None:
                app.office.lastUpdateTime = currentTime
            else:
                timeDelta = currentTime - app.office.lastUpdateTime
                app.office.workTime += (timeDelta / 15)  # Increment workTime by the delta
            app.office.lastUpdateTime = currentTime
            
            # Working decreases energy faster
            if hasattr(app, 'energy') and app.counter == 0:  # Only once per minute
                app.energy = max(0, app.energy - 1)
                
        currentTime = app.hour + app.minute / 60
        if currentTime < 8 or app.hour >= 18 or app.office.workTime >= app.office.maxWorkHours:
            app.gameState.currentScreen = "mainMap"
            app.office.officeEntryTime = None
            app.office.lastUpdateTime = None  # Reset on exit
            app.keysHeld.clear()

    if app.gameState.currentScreen not in ["welcome", "win"] and app.gameState.money >= app.goalMoney:
        # Update completed levels when player wins
        if hasattr(app, 'currentDifficulty') and app.currentDifficulty not in app.gameState.completedLevels:
            app.gameState.completedLevels.append(app.currentDifficulty)
        app.gameState.currentScreen = "win"
        app.mainMusic.pause()
        app.winMusic.play()

def onKeyPress(app, key):
    if not hasattr(app, 'keysHeld'):
        app.keysHeld = set()
    app.keysHeld.add(key)
    
    # Toggle music with "P"
    if key == 'p':
        if app.isMusicPlaying:
            app.mainMusic.pause()
            app.isMusicPlaying = False
        else:
            app.mainMusic.play(loop=True)
            app.isMusicPlaying = True

    # Check for house specific activities
    if app.gameState.currentScreen == "house":
        if key == 's':  # Sleep
            app.houseActivity = "sleeping"
            app.wakeupHour = 7
            app.wakeupMinute = 30
            app.energy = 100  # Restore energy to full
            
            # Fast-forward to next morning
            app.day += 1  # Always advance to next day
            app.hour = app.wakeupHour
            app.minute = app.wakeupMinute
            
            # Exit home and go back to map after sleeping
            app.gameState.currentScreen = "mainMap"
            # Reset avatar position to outside the house
            app.player.avatarX = 510
            app.player.avatarY = 540
            app.houseActivity = None
        
        elif key == 'e':  # Eat
            if app.gameState.money >= 5:  # Cost of food
                app.gameState.money -= 5
                app.houseActivity = "eating"
                app.energy = min(app.energy + 10, 100)  # Add energy
            
        elif key == 't':  # Watch TV
            if app.gameState.money >= 2:  # Cost of TV
                app.gameState.money -= 2
                app.houseActivity = "watching_tv"
                app.energy = min(app.energy + 5, 100)  # Add energy
            
        elif key == 'r':  # Rest
            app.houseActivity = "resting"
            app.energy = min(app.energy + 15, 100)  # Add energy
            
        elif key == 'q':
            app.gameState.currentScreen = "mainMap"
            app.houseActivity = None
            app.keysHeld.clear()

    # Other key handlers below...
    elif app.gameState.currentScreen in ["stockAAPL", "stockBRIC", "stockBLDN", "stockGLD"]:
        if key.isdigit():
            app.stock.quantityInput += key
        elif key == 'backspace':
            app.stock.quantityInput = app.stock.quantityInput[:-1]
        elif key == 'q':
            app.gameState.currentScreen = "mainMap"
            app.stock.quantityInput = ""
            app.stock.selectedStock = None
            app.keysHeld.clear()
    elif app.gameState.currentScreen == "welcome":
        if key == '1':
            app.goalMoney = 8000  # Increased from 5000 to 8000
            app.totalDays = 15
            app.daysLeft = app.totalDays - app.day
            app.gameState.currentScreen = "mainMap"
            app.currentDifficulty = "easy"
        elif key == '2' and "easy" in app.gameState.completedLevels:
            app.goalMoney = 25000  # Increased from 15000 to 25000
            app.totalDays = 30
            app.daysLeft = app.totalDays - app.day
            app.gameState.currentScreen = "mainMap"
            app.currentDifficulty = "medium"
        elif key == '3' and "medium" in app.gameState.completedLevels:
            app.goalMoney = 75000  # Increased from 50000 to 75000
            app.totalDays = 30
            app.daysLeft = app.totalDays - app.day
            app.gameState.currentScreen = "mainMap"
            app.currentDifficulty = "hard"
    elif app.gameState.currentScreen == "mainMap":
        if key == 'f':
            app.isFullMapView = True
        elif key == '1' and app.inventory.items["speedBoost"]["count"] > 0:
            app.inventory.useItem(app, "speedBoost")
        elif key == '2' and app.inventory.items["moneyMultiplier"]["count"] > 0:
            app.inventory.useItem(app, "moneyMultiplier")
        elif key == 'e' and app.startupDelay <= 0:
            for entrance in app.entrances:
                xMin = entrance["x"]
                xMax = entrance["x"] + entrance["width"]
                yMin = entrance["y"]
                yMax = entrance["y"] + entrance["height"]
                playerX = app.player.avatarX
                playerY = app.player.avatarY
                # if not app.isFullMapView:
                #     playerX -= app.mapOffsetX
                #     playerY -= app.mapOffsetY

                if (xMin <= playerX <= xMax and yMin <= playerY <= yMax):
                    print(f"Player Position: ({playerX}, {playerY})")
                    print(f"Entrance Position: ({xMin}, {yMin}) to ({xMax}, {yMax})")
                    # Office has time restrictions
                    if entrance["screen"] == "office":
                        currentTime = app.hour + app.minute / 60
                        if currentTime >= 8 and app.hour < 18 and app.office.workTime < app.office.maxWorkHours:
                            app.gameState.currentScreen = entrance["screen"]
                            app.office.officeEntryTime = time.time()
                            app.office.officeTime = 8
                            if app.day > app.office.lastWorkDay:
                                app.office.workTime = 0
                                app.office.lastWorkDay = app.day
                            app.keysHeld.clear()
                    else:
                        # All other buildings can be entered anytime
                        app.gameState.currentScreen = entrance["screen"]
                        if entrance["screen"] == "news":
                            app.news.lastNewsUpdateHour = -1
                            app.news.updateNews(app)
                        app.keysHeld.clear()
                    break
    elif app.gameState.currentScreen == "office":
        if key == 'q':
            app.gameState.currentScreen = "mainMap"
            app.office.userInput = ""
            app.keysHeld.clear()
        # elif key == 'enter':
        #     app.office.checkInput(app)
        elif key == 'backspace':
            app.office.userInput = app.office.userInput[:-1]
        currentTime = app.hour + app.minute / 60
        if key.isalpha() and len(key) == 1:
            app.office.userInput += key

        elif key == 'enter':
            if currentTime >= 8 and app.hour < 18 and app.office.workTime < app.office.maxWorkHours:
                if app.office.userInput == app.office.targetWord:
                    app.office.checkInput(app)
                else:
                    app.office.errorCount += 1
                    app.office.userInput = ""

    elif app.gameState.currentScreen == "bank":
        if key.isdigit():
            app.bank.inputAmount += key
        elif key == 'backspace':
            app.bank.inputAmount = app.bank.inputAmount[:-1]
        elif key == 'w':
            app.gameState.currentScreen = "atm"
            app.bank.inputAmount = ""
            app.bank.isWithdrawing = True
        elif key == 'q':
            app.gameState.currentScreen = "mainMap"
            app.bank.inputAmount = ""
            app.keysHeld.clear()
    elif app.gameState.currentScreen == "atm":
        if key.isdigit():
            app.bank.inputAmount += key
        elif key == 'backspace':
            app.bank.inputAmount = app.bank.inputAmount[:-1]
        elif key == 'enter' and app.bank.inputAmount.isdigit():
            amount = int(app.bank.inputAmount)
            if app.bank.withdraw(app, amount):
                app.bank.inputAmount = ""
        elif key == 'q':
            app.gameState.currentScreen = "bank"
            app.bank.inputAmount = ""
            app.keysHeld.clear()
    elif app.gameState.currentScreen == "stock":
        if key == 'q':
            app.gameState.currentScreen = "mainMap"
            app.keysHeld.clear()
    elif app.gameState.currentScreen == "portfolio":
        if key == 'q':
            app.gameState.currentScreen = "mainMap"
            app.keysHeld.clear()
    elif app.gameState.currentScreen in ["news", 'mall', 'office']:
        if key == 'q':
            app.gameState.currentScreen = "mainMap"
            app.keysHeld.clear()
    
    elif app.gameState.currentScreen in ["gameOver", "win"]:
        if key == 'r':
            onAppStart(app)
            app.gameState.currentScreen = "welcome"

def onKeyRelease(app, key):
    key = key.lower()
    if key in app.keysHeld:
        app.keysHeld.remove(key)
    if app.gameState.currentScreen == "mainMap":
        if key == 'f':
            app.isFullMapView = False

def onMousePress(app, mouseX, mouseY):
    mapWidth, mapHeight = app.mapWidth, app.mapHeight

    # Menu button (available on all screens except menu, instructions, welcome)
    if app.gameState.currentScreen not in ["menu", "instructions", "welcome"] and mapWidth - 100 <= mouseX <= mapWidth - 10 and 5 <= mouseY <= 45:
        app.isPaused = True
        app.previousScreen = app.gameState.currentScreen
        app.gameState.currentScreen = "menu"

    # Menu screen interactions
    elif app.gameState.currentScreen == "menu":
        buttonWidth = 250
        buttonHeight = 40
        buttonSpacing = 20
        startY = 200
        
        # Continue Game
        if mapWidth / 2 - buttonWidth / 2 <= mouseX <= mapWidth / 2 + buttonWidth / 2 and startY <= mouseY <= startY + buttonHeight:
            app.isPaused = False
            app.gameState.currentScreen = app.previousScreen
        
        # Instructions
        elif mapWidth / 2 - buttonWidth / 2 <= mouseX <= mapWidth / 2 + buttonWidth / 2 and startY + buttonHeight + buttonSpacing <= mouseY <= startY + 2 * buttonHeight + buttonSpacing:
            app.gameState.currentScreen = "instructions"
        
        # Quit Game
        elif mapWidth / 2 - buttonWidth / 2 <= mouseX <= mapWidth / 2 + buttonWidth / 2 and startY + 2 * (buttonHeight + buttonSpacing) <= mouseY <= startY + 3 * buttonHeight + 2 * buttonSpacing:
            onAppStart(app)  # Restart the game
            app.gameState.currentScreen = "welcome"
        
        # Back Button
        elif 20 <= mouseX <= 120 and mapHeight - 60 <= mouseY <= mapHeight - 20:
            app.gameState.currentScreen = app.previousScreen

    # Instructions screen interactions
    elif app.gameState.currentScreen == "instructions":
        # Back Button
        if 20 <= mouseX <= 120 and mapHeight - 60 <= mouseY <= mapHeight - 20:
            app.gameState.currentScreen = "menu"

    # Stock screen (selecting a stock or navigating to portfolio/mainMap)
    elif app.gameState.currentScreen == "stock":
        screenCenterX = mapWidth / 2
        screenCenterY = mapHeight / 2
        totalWidth = 800
        rectWidth = totalWidth // 4
        startX = (mapWidth - totalWidth) // 2
        y = screenCenterY - 50
        for i in range(4):
            x = startX + i * rectWidth
            if x <= mouseX <= x + rectWidth and y <= mouseY <= y + 80:
                app.stock.selectedStock = list(app.stock.stocks.keys())[i]
                app.gameState.currentScreen = f"stock{app.stock.selectedStock}"
                app.stock.quantityInput = ""
                break
        if screenCenterX - 100 <= mouseX <= screenCenterX + 100 and screenCenterY + 50 <= mouseY <= screenCenterY + 90:
            app.gameState.currentScreen = "portfolio"
        if screenCenterX - 60 <= mouseX <= screenCenterX + 60 and screenCenterY + 100 <= mouseY <= screenCenterY + 140:
            app.gameState.currentScreen = "mainMap"

    # Individual stock screens (buy/sell stocks)
    elif app.gameState.currentScreen in ["stockAAPL", "stockBRIC", "stockBLDN", "stockGLD"]:
        screenCenterX = mapWidth / 2
        screenCenterY = mapHeight / 2
        if screenCenterX - 60 <= mouseX <= screenCenterX + 60 and screenCenterY + 20 <= mouseY <= screenCenterY + 60:
            try:
                quantity = int(app.stock.quantityInput)
                if quantity > 0:
                    stock = app.stock.selectedStock
                    currentPrice = app.stock.stocks[stock]["currentPrice"]
                    totalCost = quantity * currentPrice
                    if app.gameState.money >= totalCost:
                        app.gameState.money -= totalCost
                        app.stock.portfolio[stock] = app.stock.portfolio.get(stock, 0) + quantity
                        app.stock.purchasePrices[stock] = app.stock.purchasePrices.get(stock, []) + [currentPrice] * quantity
                        app.stock.quantityInput = ""
            except ValueError:
                app.stock.quantityInput = ""
        elif screenCenterX + 70 <= mouseX <= screenCenterX + 130 and screenCenterY + 20 <= mouseY <= screenCenterY + 60:
            stock = app.stock.selectedStock
            currentPrice = app.stock.stocks[stock]["currentPrice"]
            maxShares = int(app.gameState.money // currentPrice) if currentPrice > 0 else 0
            app.stock.quantityInput = str(maxShares)
        elif screenCenterX - 60 <= mouseX <= screenCenterX + 60 and screenCenterY + 70 <= mouseY <= screenCenterY + 110:
            try:
                quantity = int(app.stock.quantityInput)
                if quantity > 0:
                    stock = app.stock.selectedStock
                    currentPrice = app.stock.stocks[stock]["currentPrice"]
                    if app.stock.portfolio.get(stock, 0) >= quantity:
                        app.stock.portfolio[stock] -= quantity
                        app.gameState.money += quantity * currentPrice
                        purchasePrices = app.stock.purchasePrices.get(stock, [])
                        app.stock.purchasePrices[stock] = purchasePrices[quantity:] if len(purchasePrices) > quantity else []
                        app.stock.quantityInput = ""
            except ValueError:
                app.stock.quantityInput = ""
        elif screenCenterX + 70 <= mouseX <= screenCenterX + 130 and screenCenterY + 70 <= mouseY <= screenCenterY + 110:
            stock = app.stock.selectedStock
            maxShares = app.stock.portfolio.get(stock, 0)
            app.stock.quantityInput = str(maxShares)
        if screenCenterX - 60 <= mouseX <= screenCenterX + 60 and screenCenterY + 120 <= mouseY <= screenCenterY + 160:
            app.gameState.currentScreen = "stock"
            app.stock.quantityInput = ""
            app.stock.selectedStock = None

    # Portfolio screen (back to stock screen)
    elif app.gameState.currentScreen == "portfolio":
        screenCenterX = mapWidth / 2
        buttonY = 610  # Bottom area buttons
        
        # Back button (left side)
        if 150 <= mouseX <= 310 and buttonY <= mouseY <= buttonY + 50:
            app.gameState.currentScreen = "mainMap"
            
        # Stock Exchange button (center)
        if screenCenterX - 90 <= mouseX <= screenCenterX + 90 and buttonY <= mouseY <= buttonY + 50:
            app.gameState.currentScreen = "stock"
            
        # Trade button (right side)
        if mapWidth - 310 <= mouseX <= mapWidth - 150 and buttonY <= mouseY <= buttonY + 50:
            # Navigate to the first stock for trading
            app.stock.selectedStock = list(app.stock.stocks.keys())[0]
            app.gameState.currentScreen = f"stock{app.stock.selectedStock}"
            app.stock.quantityInput = ""

    # News screen (back to mainMap)
    elif app.gameState.currentScreen == "news":
        screenCenterX = mapWidth / 2
        screenCenterY = mapHeight / 2
        
        # Define parameters for layout
        tabWidth = mapWidth / 4  # Updated to match the 4 tabs
        tabHeight = 40
        tabY = 150
        contentY = tabY + tabHeight + 10
        contentHeight = mapHeight - contentY - 50
        leftColumnWidth = mapWidth * 0.6
        rightX = leftColumnWidth
        rightWidth = mapWidth - leftColumnWidth
        
        # Check if back button clicked
        if 20 <= mouseX <= 140 and mapHeight - 60 <= mouseY <= mapHeight - 20:
            app.gameState.currentScreen = "mainMap"

        # Check for tab clicks
        if tabY <= mouseY <= tabY + tabHeight:
            for i, category in enumerate(["Headlines", "Analysis", "Stocks", "Portfolio"]):
                if i * tabWidth <= mouseX <= (i + 1) * tabWidth:
                    # Set active tab or navigate to appropriate screens
                    if category in ["Headlines", "Analysis"]:
                        app.activeNewsTab = category
                    elif category == "Stocks":
                        app.gameState.currentScreen = "stock"
                    elif category == "Portfolio":
                        app.gameState.currentScreen = "portfolio"
                    break
        
        # Check for stock clicks in the Headlines tab market summary to change the chart
        if app.activeNewsTab == "Headlines" and rightX <= mouseX <= rightX + rightWidth and contentY + 40 <= mouseY <= contentY + 180:
            summaryY = contentY + 60
            for i, stock in enumerate(app.stock.stocks):
                if summaryY - 15 <= mouseY <= summaryY + 15:
                    app.stock.selectedStock = stock
                    break
                summaryY += 30
                
        # Check for chart clicks in Analysis tab to navigate to specific stock screens
        elif app.activeNewsTab == "Analysis" and 10 <= mouseX <= mapWidth - 10 and contentY + 40 <= mouseY <= contentY + contentHeight:
            chartPadding = 20
            chartWidth = (mapWidth - 20 - (chartPadding * 3)) / 2
            chartHeight = (contentHeight - 40 - (chartPadding * 2)) / 2
            
            # Check which chart was clicked
            for i, stock in enumerate(app.stock.stocks):
                row = i // 2
                col = i % 2
                
                chartX = 10 + (chartWidth + chartPadding) * col
                chartY = contentY + 50 + (chartHeight + chartPadding) * row
                
                if chartX <= mouseX <= chartX + chartWidth and chartY <= mouseY <= chartY + chartHeight:
                    # Navigate to the specific stock screen
                    app.stock.selectedStock = stock
                    app.gameState.currentScreen = f"stock{stock}"
                    app.stock.quantityInput = ""
                    break

    # Bank screen interactions
    elif app.gameState.currentScreen == "bank":
        screenCenterX, screenCenterY = app.width // 2, app.height // 2
        # Back button
        if 20 <= mouseX <= 100 and 20 <= mouseY <= 50:
            app.gameState.currentScreen = "mainMap"
            app.bank.inputAmount = ""
            app.bank.inputActive = False
        # Deposit input field
        elif screenCenterX - 150 <= mouseX <= screenCenterX + 150 and 230 <= mouseY <= 270:
            app.bank.inputActive = True
            app.bank.isWithdrawing = False
        # Deposit button
        elif screenCenterX - 75 <= mouseX <= screenCenterX + 75 and 290 <= mouseY <= 330:
            if app.bank.inputAmount.isdigit() and int(app.bank.inputAmount) > 0:
                amount = int(app.bank.inputAmount)
                if app.bank.deposit(app, amount):
                    app.bank.inputAmount = ""
                    app.bank.inputActive = False
        # ATM button
        elif screenCenterX - 150 <= mouseX <= screenCenterX + 150 and 350 <= mouseY <= 390:
            app.gameState.currentScreen = "atm"
            app.bank.inputAmount = ""
            app.bank.isWithdrawing = True
        # Fixed Deposit button
        elif screenCenterX - 150 <= mouseX <= screenCenterX + 150 and 410 <= mouseY <= 450:
            app.gameState.currentScreen = "fixedDeposit"
            app.bank.inputAmount = ""
            app.bank.inputActive = False

    # ATM screen interactions
    elif app.gameState.currentScreen == "atm":
        screenCenterX, screenCenterY = app.width // 2, app.height // 2
        # Back button
        if 20 <= mouseX <= 100 and 20 <= mouseY <= 50:
            app.gameState.currentScreen = "bank"
            app.bank.inputAmount = ""
            app.bank.inputActive = False
        # Withdrawal input field
        elif screenCenterX - 150 <= mouseX <= screenCenterX + 150 and 230 <= mouseY <= 270:
            app.bank.inputActive = True
            app.bank.isWithdrawing = True
        # Withdraw button
        elif screenCenterX - 75 <= mouseX <= screenCenterX + 75 and 290 <= mouseY <= 330:
            if app.bank.inputAmount.isdigit() and int(app.bank.inputAmount) > 0:
                amount = int(app.bank.inputAmount)
                if app.bank.withdraw(app, amount):
                    app.bank.inputAmount = ""
                    app.bank.inputActive = False
        # Quick withdrawal buttons
        elif 400 <= mouseY <= 440:
            # Calculate positions for quick withdrawal buttons
            buttonWidth = 90
            buttonSpacing = 20
            totalWidth = buttonWidth * 3 + buttonSpacing * 2
            startX = screenCenterX - totalWidth / 2
            
            # Check which quick withdrawal button was clicked
            for i, amount in enumerate([50, 100, 200]):
                x = startX + i * (buttonWidth + buttonSpacing)
                if x <= mouseX <= x + buttonWidth:
                    if app.bank.withdraw(app, amount):
                        app.bank.inputAmount = ""
                        app.bank.inputActive = False
                        break

    # Fixed Deposit screen (deposit, claim matured deposits)
    elif app.gameState.currentScreen == "fixedDeposit":
        screenCenterX, screenCenterY = app.width // 2, app.height // 2
        # Back button
        if 20 <= mouseX <= 100 and 20 <= mouseY <= 50:
            app.gameState.currentScreen = "bank"
            app.bank.inputAmount = ""
            app.bank.inputActive = False
        # Deposit input field
        elif screenCenterX - 100 <= mouseX <= screenCenterX + 100 and 130 <= mouseY <= 160:
            app.bank.inputActive = True
            app.bank.isWithdrawing = False
        # Deposit button
        elif screenCenterX - 50 <= mouseX <= screenCenterX + 50 and 170 <= mouseY <= 200:
            if app.bank.inputAmount.isdigit() and int(app.bank.inputAmount) > 0:
                amount = int(app.bank.inputAmount)
                if amount <= app.gameState.money:
                    app.fixedDeposits.append(FixedDeposit(amount, app.day, app.fixedDepositTerm))
                    app.gameState.money -= amount
                    app.bank.inputAmount = ""
                    app.bank.inputActive = False
        # Claim matured deposits
        y = 260
        for i, fd in enumerate(app.fixedDeposits):
            if fd.isMatured(app.day) and screenCenterX + 220 <= mouseX <= screenCenterX + 300 and y - 10 <= mouseY <= y + 10:
                app.gameState.money += fd.calculateValue(app.day)
                app.fixedDeposits.pop(i)
                break
            y += 40

    # Office screen (back to mainMap)
    elif app.gameState.currentScreen == "office":
        screenCenterX = mapWidth / 2
        screenCenterY = mapHeight / 2
        if screenCenterX - 60 <= mouseX <= screenCenterX + 60 and screenCenterY + 120 <= mouseY <= screenCenterY + 160:
            app.gameState.currentScreen = "mainMap"
            app.office.officeEntryTime = None
            app.office.lastUpdateTime = None
            app.keysHeld.clear()

    # Welcome screen (start game)
    elif app.gameState.currentScreen == "welcome":
        screenCenterX = mapWidth / 2
        screenCenterY = mapHeight / 2
        if screenCenterX - 100 <= mouseX <= screenCenterX + 100 and screenCenterY + 50 <= mouseY <= screenCenterY + 90:
            app.gameState.currentScreen = "mainMap"

    # House screen interactions
    elif app.gameState.currentScreen == "house":
        screenCenterX = mapWidth / 2
        buttonWidth = 200
        buttonHeight = 80
        buttonSpacing = 40
        startY = 220  # Updated to match the new position
        
        # Back button
        if 20 <= mouseX <= 140 and mapHeight - 60 <= mouseY <= mapHeight - 20:
            app.gameState.currentScreen = "mainMap"
            app.houseActivity = None
            
        # Sleep button
        if (screenCenterX - buttonWidth - buttonSpacing/2 <= mouseX <= screenCenterX - buttonSpacing/2 and 
            startY <= mouseY <= startY + buttonHeight):
            app.houseActivity = "sleeping"
            app.wakeupHour = 7
            app.wakeupMinute = 30
            app.energy = 100  # Restore energy to full
            
            # Fast-forward to next morning
            app.day += 1  # Always advance to next day
            app.hour = app.wakeupHour
            app.minute = app.wakeupMinute
            
            # Exit home and go back to map after sleeping
            app.gameState.currentScreen = "mainMap"
            # Reset avatar position to outside the house
            app.player.avatarX = 510
            app.player.avatarY = 540
            app.houseActivity = None
            
        # Eat button
        elif (screenCenterX + buttonSpacing/2 <= mouseX <= screenCenterX + buttonSpacing/2 + buttonWidth and 
              startY <= mouseY <= startY + buttonHeight):
            if app.gameState.money >= 5:  # Cost of food
                app.gameState.money -= 5
                app.houseActivity = "eating"
                app.energy = min(app.energy + 10, 100)  # Add energy
                
        # TV button
        elif (screenCenterX - buttonWidth - buttonSpacing/2 <= mouseX <= screenCenterX - buttonSpacing/2 and 
              startY + buttonHeight + buttonSpacing <= mouseY <= startY + 2*buttonHeight + buttonSpacing):
            if app.gameState.money >= 2:  # Cost of TV
                app.gameState.money -= 2
                app.houseActivity = "watching_tv"
                app.energy = min(app.energy + 5, 100)  # Add energy
                
        # Rest button
        elif (screenCenterX + buttonSpacing/2 <= mouseX <= screenCenterX + buttonSpacing/2 + buttonWidth and 
              startY + buttonHeight + buttonSpacing <= mouseY <= startY + 2*buttonHeight + buttonSpacing):
            app.houseActivity = "resting"
            app.energy = min(app.energy + 15, 100)  # Add energy
    
    # Mall screen interactions
    elif app.gameState.currentScreen == "mall":
        screenCenterX = mapWidth / 2
        
        # Category tabs
        tabWidth = mapWidth / len(app.mall.categories)
        tabHeight = 40
        tabY = 130
        
        # Check for clicks on category tabs
        if tabY <= mouseY <= tabY + tabHeight:
            for i, category in enumerate(app.mall.categories):
                x = i * tabWidth
                if x <= mouseX <= x + tabWidth:
                    app.mall.currentCategory = category
                    app.mall.selectedItem = None  # Clear selection when changing category
                    break
        
        # Content area parameters
        contentY = tabY + tabHeight + 10
        contentHeight = mapHeight - contentY - 60
        leftPanelWidth = mapWidth * 0.6
        rightX = leftPanelWidth
        rightWidth = mapWidth - leftPanelWidth
        
        # Check for clicks on items in the left panel
        items = app.mall.inventory.get(app.mall.currentCategory, [])
        itemY = contentY + 60
        itemHeight = min(90, (contentHeight - 60) / max(len(items), 1))
        
        if 15 <= mouseX <= leftPanelWidth - 15 and contentY + 40 <= mouseY <= contentY + contentHeight:
            for i, item in enumerate(items):
                if itemY - 10 <= mouseY <= itemY - 10 + itemHeight:
                    app.mall.selectedItem = item["id"]
                    break
                itemY += itemHeight
        
        # Check for buy button click in item details
        if app.mall.selectedItem:
            # Find the selected item
            selectedItem = None
            for category in app.mall.inventory:
                for item in app.mall.inventory[category]:
                    if item["id"] == app.mall.selectedItem:
                        selectedItem = item
                        break
                if selectedItem:
                    break
            
            if selectedItem:
                buttonY = contentY + contentHeight - 100
                if (rightX + rightWidth/2 - 60 <= mouseX <= rightX + rightWidth/2 + 60 and 
                    buttonY <= mouseY <= buttonY + 40 and 
                    app.gameState.money >= selectedItem["price"]):
                    # Process purchase
                    app.gameState.money -= selectedItem["price"]
                    itemId = selectedItem["id"]
                    itemType = itemId[0]  # First letter of ID indicates type (c=clothing, e=electronics, etc.)
                    
                    # Add to inventory based on item type
                    if itemType == "i":  # Items
                        if itemId == "i1":  # Speed Boost
                            app.inventory.items["speedBoost"]["count"] += 1
                        elif itemId == "i2":  # Money Multiplier
                            app.inventory.items["moneyMultiplier"]["count"] += 1
                    
                    # Add different effects for other item types
                    elif itemType == "c":  # Clothing
                        if itemId == "c1":  # Business Suit
                            app.office.earningMultiplier *= 1.1
                        elif itemId == "c2":  # Casual Outfit
                            app.player.energyDrainRate *= 0.95
                        elif itemId == "c3":  # Running Shoes
                            app.player.speedMultiplier *= 1.15
                    
                    elif itemType == "e":  # Electronics
                        if itemId == "e3":  # Smartwatch
                            app.player.healthRegenRate *= 1.1
                    
                    elif itemType == "f":  # Food
                        if itemId == "f1":  # Energy Drink
                            app.energy = min(app.energy + 20, 100)
                        elif itemId == "f2":  # Healthy Meal
                            app.energy = min(app.energy + 10, 100)
                        elif itemId == "f3":  # Luxury Dinner
                            app.energy = 100
        
        # Check for back button click
        if 20 <= mouseX <= 140 and mapHeight - 50 <= mouseY <= mapHeight - 10:
            app.gameState.currentScreen = "mainMap"
            app.mall.selectedItem = None

    # Win screen interactions
    elif app.gameState.currentScreen == "win":
        # Return to menu button
        if mapWidth / 2 - 150 <= mouseX <= mapWidth / 2 + 150 and 480 <= mouseY <= 530:
            app.gameState.currentScreen = "welcome"
            # Don't reset the completedLevels, but reset other game variables
            app.day = 1
            app.hour = 8
            app.minute = 0
            app.gameState.money = 100
            app.bank.balance = 0
            app.stock.portfolio = {}
            app.stock.purchasePrices = {}

def drawWinScreen(app):
    drawRect(0, 0, mapWidth, mapHeight, fill="darkBlue")
    drawRect(0, 0, mapWidth, mapHeight, fill="gold", opacity=30)
    
    # Win title
    drawLabel("CONGRATULATIONS!", mapWidth / 2, 100, size=50, fill="gold", bold=True)
    drawLabel(f"You reached ${app.goalMoney:,} in {app.totalDays - app.daysLeft} days!", 
              mapWidth / 2, 160, size=30, fill="white", bold=True)
    
    # Money breakdown
    drawLabel("Your Financial Summary:", mapWidth / 2, 230, size=25, fill="white", bold=True)
    drawLabel(f"Cash: ${app.gameState.money:.2f}", mapWidth / 2, 270, size=20, fill="white")
    drawLabel(f"Bank Balance: ${app.bank.balance:.2f}", mapWidth / 2, 300, size=20, fill="white")
    
    # Calculate portfolio value
    portfolioValue = 0
    for stock, quantity in app.stock.portfolio.items():
        if quantity > 0:
            portfolioValue += quantity * app.stock.stocks[stock]["currentPrice"]
    
    drawLabel(f"Stock Portfolio: ${portfolioValue:.2f}", mapWidth / 2, 330, size=20, fill="white")
    drawLabel(f"Total Net Worth: ${(app.gameState.money + app.bank.balance + portfolioValue):.2f}", 
              mapWidth / 2, 370, size=25, fill="gold", bold=True)
    
    # Level completion message
    if app.currentDifficulty == "easy":
        drawLabel("You've unlocked the Medium difficulty level!", mapWidth / 2, 420, size=22, fill="orange", bold=True)
    elif app.currentDifficulty == "medium":
        drawLabel("You've unlocked the Hard difficulty level!", mapWidth / 2, 420, size=22, fill="red", bold=True)
    elif app.currentDifficulty == "hard":
        drawLabel("Congratulations! You've mastered all difficulty levels!", mapWidth / 2, 420, size=22, fill="gold", bold=True)
    
    # Return to menu button
    drawRect(mapWidth / 2 - 150, 480, 300, 50, fill="green", border="white", borderWidth=2)
    drawLabel("Return to Main Menu", mapWidth / 2, 505, size=25, fill="white", bold=True)
    
    # Play again prompts
    drawLabel("Press 'R' to play again", mapWidth / 2, 550, size=20, fill="white")
    
    # Display a different financial wisdom message based on difficulty level
    if app.currentDifficulty == "easy":
        advice = "Tip: Diversify your investments to reduce risk!"
    elif app.currentDifficulty == "medium":
        advice = "Tip: Fixed deposits offer guaranteed returns. Try them in harder difficulties!"
    else:
        advice = "Tip: Watch the news! Market changes can create big opportunities."
    
    drawLabel(advice, mapWidth / 2, 600, size=18, fill="lightCyan", italic=True)

def redrawAll(app):
    if app.gameState.currentScreen == "welcome":
        drawWelcomeScreen(app)
    elif app.gameState.currentScreen == "mainMap":
        drawMainMap(app)
    elif app.gameState.currentScreen == "office":
        drawOfficeScreen(app)
    elif app.gameState.currentScreen == "bank":
        drawBankScreen(app)
    elif app.gameState.currentScreen == "fixedDeposit":
        drawFixedDepositScreen(app)
    elif app.gameState.currentScreen == "atm":
        drawAtmScreen(app)
    elif app.gameState.currentScreen == "mall":
        drawMallScreen(app)
    elif app.gameState.currentScreen == "stock":
        drawStockScreen(app)
    elif app.gameState.currentScreen == "stockAAPL":
        drawStockScreenAAPL(app)
    elif app.gameState.currentScreen == "stockBRIC":
        drawStockScreenBRIC(app)
    elif app.gameState.currentScreen == "stockBLDN":
        drawStockScreenBLDN(app)
    elif app.gameState.currentScreen == "stockGLD":
        drawStockScreenGLD(app)
    elif app.gameState.currentScreen == "portfolio":
        drawPortfolioScreen(app)
    elif app.gameState.currentScreen == "gameOver":
        drawRect(0, 0, mapWidth, mapHeight, fill="black", opacity=80)
        drawLabel("Game Over! You ran out of time.", mapWidth / 2, mapHeight / 2 - 50, size=40, fill="red")
        drawLabel("Press R to restart", mapWidth / 2, mapHeight / 2, size=20, fill="white")
    elif app.gameState.currentScreen == "win":
        drawWinScreen(app)
    elif app.gameState.currentScreen == "news":
        drawNewsScreen(app)
    elif app.gameState.currentScreen == "house":
        drawHouseScreen(app)
    elif app.gameState.currentScreen == "menu":
        drawMenuScreen(app)
    elif app.gameState.currentScreen == "instructions":
        drawInstructionsScreen(app)

runApp(1000, 700)

